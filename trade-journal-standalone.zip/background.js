var WINDOW_ID = null;

chrome.action.onClicked.addListener(function() {
  if (WINDOW_ID !== null) {
    chrome.windows.get(WINDOW_ID, function(win) {
      if (chrome.runtime.lastError || !win) {
        WINDOW_ID = null;
        openWindow();
      } else {
        chrome.windows.update(WINDOW_ID, {
          focused: true
        });
      }
    });
  } else {
    openWindow();
  }
});

function openWindow() {
  chrome.windows.create({
    url: chrome.runtime.getURL("popup.html"),
    type: "popup",
    width: 900,
    height: 760,
    focused: true
  }, function(win) {
    WINDOW_ID = win.id;
  });
}

chrome.windows.onRemoved.addListener(function(windowId) {
  if (windowId === WINDOW_ID) WINDOW_ID = null;
});

chrome.runtime.onMessage.addListener(function(msg, sender, sendResponse) {
  if (msg.action === "fetchCandles") {
    bg_fetchCandles(msg.ticker, msg.fromMs, msg.toMs, msg.resolution, msg.polygonKey, msg.finnhubKey, msg.range).then(function(result) {
      sendResponse({
        ok: true,
        candles: result
      });
    }).catch(function(e) {
      sendResponse({
        ok: false,
        error: e.message
      });
    });
    return true;
  }
});

async function bg_fetchCandles(ticker, fromMs, toMs, resolution, polygonKey, finnhubKey, dailyRange) {
  if (resolution === "daily") {
    var rangeStr = /^(1mo|3mo|6mo|1y|2y)$/.test(dailyRange || "") ? dailyRange : "1mo";
    var yhUrl = "https://query2.finance.yahoo.com/v8/finance/chart/" + encodeURIComponent(ticker) + "?interval=1d&range=" + rangeStr + "&includePrePost=false";
    var yr = await fetch(yhUrl, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "User-Agent": "Mozilla/5.0"
      }
    });
    if (!yr.ok) throw new Error("Yahoo daily HTTP " + yr.status);
    var yd = await yr.json();
    var result = yd && yd.chart && yd.chart.result && yd.chart.result[0];
    if (!result || !result.timestamp || !result.timestamp.length) throw new Error("Yahoo: no daily data for " + ticker);
    var q = result.indicators.quote[0];
    return result.timestamp.map(function(ts, i) {
      if (q.close[i] == null) return null;
      return {
        time: ts,
        open: q.open[i] || q.close[i],
        high: q.high[i] || q.close[i],
        low: q.low[i] || q.close[i],
        close: q.close[i],
        volume: q.volume[i] || 0
      };
    }).filter(Boolean);
  }
  var yhError = null;
  try {
    var interval = resolution <= 1 ? "1m" : resolution <= 2 ? "2m" : resolution <= 5 ? "5m" : "15m";
    var range = (resolution || 1) <= 1 ? "5d" : "1mo";
    var yhUrl = "https://query2.finance.yahoo.com/v8/finance/chart/" + encodeURIComponent(ticker) + "?interval=" + interval + "&range=" + range + "&includePrePost=true";
    var yr = await fetch(yhUrl, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "User-Agent": "Mozilla/5.0"
      }
    });
    if (yr.ok) {
      var yd = await yr.json();
      var result = yd && yd.chart && yd.chart.result && yd.chart.result[0];
      if (result && result.timestamp && result.timestamp.length) {
        var allTs = result.timestamp;
        var q = result.indicators.quote[0];
        var candles = [];
        for (var i = 0; i < allTs.length; i++) {
          var tMs = allTs[i] * 1e3;
          if (tMs < fromMs || tMs > toMs) continue;
          if (q.open[i] == null || q.close[i] == null) continue;
          candles.push({
            time: allTs[i],
            open: q.open[i],
            high: q.high[i],
            low: q.low[i],
            close: q.close[i],
            volume: q.volume[i] || 0
          });
        }
        if (candles.length) return candles;
        var errDate = new Date(fromMs).toISOString().slice(0, 10);
        yhError = "no data for " + errDate + " — market may have been closed (weekend/holiday), or date is beyond Yahoo's 7-day 1m window";
      } else {
        var errCode = yd && yd.chart && yd.chart.error && yd.chart.error.code;
        yhError = errCode ? "Yahoo error: " + errCode : "empty result";
      }
    } else {
      yhError = "HTTP " + yr.status;
    }
  } catch (e) {
    yhError = e.message;
  }
  if (polygonKey) {
    var fromDate = new Date(fromMs).toISOString().slice(0, 10);
    var toDate = new Date(toMs).toISOString().slice(0, 10);
    var url = "https://api.polygon.io/v2/aggs/ticker/" + encodeURIComponent(ticker) + "/range/" + resolution + "/minute/" + fromDate + "/" + toDate + "?adjusted=false&sort=asc&limit=5000&apiKey=" + encodeURIComponent(polygonKey);
    var r = await fetch(url, {
      method: "GET",
      headers: {
        Accept: "application/json"
      }
    });
    if (!r.ok) throw new Error("Polygon HTTP " + r.status + " — free tier does not include 1m history (paid plan required). Yahoo also failed: " + (yhError || "no data"));
    var data = await r.json();
    if (!data.results || !data.results.length) throw new Error("Polygon: no data for " + ticker);
    return data.results.map(function(b) {
      return {
        time: Math.floor(b.t / 1e3),
        open: b.o,
        high: b.h,
        low: b.l,
        close: b.c,
        volume: b.v
      };
    });
  }
  if (finnhubKey) {
    var fromSec = Math.floor(fromMs / 1e3);
    var toSec = Math.floor(toMs / 1e3);
    var res = resolution === 1 ? "1" : resolution === 5 ? "5" : "1";
    var url = "https://finnhub.io/api/v1/stock/candle?symbol=" + encodeURIComponent(ticker) + "&resolution=" + res + "&from=" + fromSec + "&to=" + toSec + "&token=" + encodeURIComponent(finnhubKey);
    var r = await fetch(url, {
      method: "GET",
      headers: {
        Accept: "application/json"
      }
    });
    if (!r.ok) throw new Error("Finnhub HTTP " + r.status);
    var data = await r.json();
    if (data.s !== "ok" || !data.t || !data.t.length) throw new Error("Finnhub: no data for " + ticker);
    return data.t.map(function(ts, i) {
      return {
        time: ts,
        open: data.o[i],
        high: data.h[i],
        low: data.l[i],
        close: data.c[i],
        volume: data.v[i]
      };
    });
  }
  throw new Error(yhError && yhError.indexOf("Failed to fetch") !== -1 ? "Chart data unavailable — please reload the extension (chrome://extensions → Trade Journal → Reload) to activate new permissions, then try again." : "No chart data available for this date. Yahoo Finance only covers the last 7 days. Add a Finnhub key under “Chart data (optional)” for up to 1 month of history." + (yhError ? " (" + yhError + ")" : ""));
}
