'use strict';

// ── TradingView scanner proxy ──────────────────────────────────────────
// The popup can't reliably POST to scanner.tradingview.com from the page
// context (CORS), so every scan goes through here: the popup builds the
// request body, this POSTs it and returns the JSON. (A second action below
// proxies daily-bar history for the chart.)

const TV_SCAN_URL =
  'https://scanner.tradingview.com/america/scan?label-product=screener-stock';

// ── Daily-bar history proxy (for the tap-to-chart feature) ─────────────
// The scanner endpoint only returns snapshots, never OHLC time series, so
// charting needs a real history source. Yahoo's v8 chart endpoint is the
// primary (no key, JSON OHLC); Stooq CSV is a no-key fallback. Both are
// cross-origin, so they go through the worker just like the scan.

function yahooSymbol(sym) {
  var s = String(sym || '').toUpperCase().replace(/^.*:/, '').trim();
  if (s === 'VIX' || s === '^VIX') return '%5EVIX'; // ^VIX url-encoded
  return encodeURIComponent(s);
}
function stooqSymbol(sym) {
  var s = String(sym || '').toUpperCase().replace(/^.*:/, '').trim();
  if (s === 'VIX' || s === '^VIX') return '%5Evix';
  return encodeURIComponent(s.toLowerCase()) + '.us';
}
function rangeToDays(range) { return range === '3mo' ? 63 : 126; } // ~trading days

// Yahoo v8: returns { chart:{ result:[{ timestamp:[], indicators:{quote:[{open,high,low,close}]} }] } }
function fetchYahoo(sym, range) {
  var hosts = ['query1.finance.yahoo.com', 'query2.finance.yahoo.com'];
  var path = '/v8/finance/chart/' + yahooSymbol(sym) +
    '?range=' + encodeURIComponent(range) + '&interval=1d&includePrePost=false';
  function tryHost(i) {
    if (i >= hosts.length) return Promise.reject(new Error('yahoo unreachable'));
    return fetch('https://' + hosts[i] + path, { method: 'GET' })
      .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
      .then(function (j) {
        var res = j && j.chart && j.chart.result && j.chart.result[0];
        var ts = res && res.timestamp;
        var q = res && res.indicators && res.indicators.quote && res.indicators.quote[0];
        if (!ts || !q) throw new Error('empty');
        var bars = [];
        for (var k = 0; k < ts.length; k++) {
          var o = q.open[k], h = q.high[k], l = q.low[k], c = q.close[k];
          if (o == null || h == null || l == null || c == null) continue;
          var d = new Date(ts[k] * 1000); // daily ts ~14:30 UTC → UTC date == ET date
          var iso = d.toISOString().slice(0, 10);
          bars.push({ time: iso, open: +o, high: +h, low: +l, close: +c });
        }
        if (!bars.length) throw new Error('no bars');
        return { bars: bars, source: 'yahoo' };
      })
      .catch(function () { return tryHost(i + 1); });
  }
  return tryHost(0);
}

// Stooq CSV fallback: full daily history → slice to the requested window.
function fetchStooq(sym, range) {
  var url = 'https://stooq.com/q/d/l/?s=' + stooqSymbol(sym) + '&i=d';
  return fetch(url, { method: 'GET' })
    .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); })
    .then(function (txt) {
      var lines = String(txt || '').trim().split(/\r?\n/);
      if (lines.length < 2 || lines[0].indexOf('Date') === -1) throw new Error('stooq bad csv');
      var bars = [];
      for (var i = 1; i < lines.length; i++) {
        var p = lines[i].split(',');
        if (p.length < 5) continue;
        var o = parseFloat(p[1]), h = parseFloat(p[2]), l = parseFloat(p[3]), c = parseFloat(p[4]);
        if (!isFinite(o) || !isFinite(h) || !isFinite(l) || !isFinite(c)) continue;
        bars.push({ time: p[0], open: o, high: h, low: l, close: c });
      }
      if (!bars.length) throw new Error('stooq empty');
      var n = rangeToDays(range);
      if (bars.length > n) bars = bars.slice(bars.length - n);
      return { bars: bars, source: 'stooq' };
    });
}

function fetchHistory(sym, range) {
  return fetchYahoo(sym, range).catch(function () { return fetchStooq(sym, range); });
}

// ── News proxy ─────────────────────────────────────────────────────────
// Finnhub company-news gives real summaries (needs the user's free key).
// TradingView's headlines endpoint is internal/unofficial. The working
// mechanics (learned from a larger build): it must be called from the
// background worker (popup fetch is CORS-blocked), `client=overview`
// returns empty, the live payload is { status:'success', data:[…] } (so
// read `data`, not `items`), and `published` is epoch SECONDS. We probe a
// few client values and the prefixed/bare symbol, lock onto whatever
// returns items, and degrade to [] on failure.
var NEWS_NOISE = ['motley fool', 'zacks', 'seeking alpha', 'investorplace', 'tipranks', 'simply wall'];
function isNoisySource(src) {
  var s = String(src || '').toLowerCase();
  return NEWS_NOISE.some(function (n) { return s.indexOf(n) !== -1; });
}
function ymd(d) { return d.toISOString().slice(0, 10); }

function fetchFinnhubNews(symbol, key) {
  if (!key || !symbol) return Promise.resolve([]);
  var to = new Date(), from = new Date(Date.now() - 2 * 864e5); // 2-day window
  var url = 'https://finnhub.io/api/v1/company-news?symbol=' + encodeURIComponent(symbol) +
    '&from=' + ymd(from) + '&to=' + ymd(to) + '&token=' + encodeURIComponent(key);
  return fetch(url)
    .then(function (r) { if (!r.ok) throw new Error('finnhub HTTP ' + r.status); return r.json(); })
    .then(function (arr) {
      if (!Array.isArray(arr)) return [];
      return arr
        .filter(function (n) { return n && n.headline && n.url && !isNoisySource(n.source); })
        .sort(function (a, b) { return (b.datetime || 0) - (a.datetime || 0); })
        .slice(0, 3)
        .map(function (n) {
          return {
            headline: String(n.headline), summary: String(n.summary || '').slice(0, 280),
            url: String(n.url), source: String(n.source || ''), ts: (n.datetime || 0) * 1000
          };
        });
    })
    .catch(function () { return []; });
}

var __tvClient = null; // cache the client= value that worked, for this worker's life
function _tvFetchItems(sym, client) {
  var url = 'https://news-headlines.tradingview.com/v2/headlines?client=' +
    encodeURIComponent(client) + '&lang=en&symbol=' + encodeURIComponent(sym);
  return fetch(url)
    .then(function (r) { if (!r.ok) throw new Error('tv HTTP ' + r.status); return r.json(); })
    .then(function (j) {
      return Array.isArray(j) ? j
        : (j && Array.isArray(j.data)) ? j.data       // live shape: { status, data:[…] }
          : (j && Array.isArray(j.items)) ? j.items   // older shape
            : [];
    });
}
function _tvParse(items) {
  var cutoff = Math.floor(Date.now() / 1000) - 24 * 3600; // last 24h
  return (items || []).map(function (n) {
    n = n || {};
    var title = String(n.title || n.headline || '').trim();
    if (!title) return null;
    var pub = (typeof n.published === 'number') ? n.published
      : (typeof n.published_at === 'number') ? n.published_at : 0;
    var sec = pub > 1e11 ? Math.floor(pub / 1000) : pub; // ms→s guard
    if (sec && sec < cutoff) return null;
    var srcRaw = n.source || n.provider || '';
    var src = (srcRaw && typeof srcRaw === 'object') ? (srcRaw.name || srcRaw.id || 'TradingView') : String(srcRaw || 'TradingView');
    if (isNoisySource(src)) return null;
    var link = n.link || '';
    if (!link && n.storyPath) link = 'https://www.tradingview.com' + n.storyPath;
    if (!link) return null;
    return {
      title: title.slice(0, 200), url: link, source: src.slice(0, 40),
      summary: String(n.shortDescription || n.summary || '').slice(0, 280),
      ts: (sec || Math.floor(Date.now() / 1000)) * 1000
    };
  }).filter(Boolean);
}
function fetchTVNews(tvSymbol, bareTicker) {
  var syms = [];
  if (tvSymbol) syms.push(tvSymbol);
  if (bareTicker && bareTicker !== tvSymbol) syms.push(bareTicker);
  if (!syms.length) return Promise.resolve([]);
  var clients = __tvClient ? [__tvClient] : ['symbol', 'overview', 'landing_page', 'widget'];
  function tryCombo(ci, si) {
    if (ci >= clients.length) return Promise.resolve([]);
    if (si >= syms.length) return tryCombo(ci + 1, 0);
    return _tvFetchItems(syms[si], clients[ci])
      .then(function (items) {
        var parsed = _tvParse(items);
        if (parsed.length) { __tvClient = clients[ci]; return parsed.slice(0, 3); }
        return tryCombo(ci, si + 1);
      })
      .catch(function () { return tryCombo(ci, si + 1); });
  }
  return tryCombo(0, 0);
}

chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
  if (msg && msg.action === 'tvScan') {
    fetch(TV_SCAN_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(msg.body || {})
    })
      .then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        return r.json();
      })
      .then(function (data) { sendResponse({ ok: true, data: data }); })
      .catch(function (e) { sendResponse({ ok: false, error: e.message }); });
    return true; // keep the message channel open for the async response
  }

  if (msg && msg.action === 'chartHistory') {
    var range = (msg.range === '3mo' || msg.range === '6mo') ? msg.range : '6mo';
    fetchHistory(msg.symbol, range)
      .then(function (out) { sendResponse({ ok: true, bars: out.bars, source: out.source }); })
      .catch(function (e) { sendResponse({ ok: false, error: e.message }); });
    return true; // async
  }

  if (msg && msg.action === 'news') {
    Promise.all([
      fetchFinnhubNews(msg.symbol, msg.finnhubKey),
      fetchTVNews(msg.tvSymbol, msg.symbol)
    ])
      .then(function (res) { sendResponse({ ok: true, finnhub: res[0], tradingview: res[1] }); })
      .catch(function (e) { sendResponse({ ok: false, error: e.message }); });
    return true; // async
  }
});
