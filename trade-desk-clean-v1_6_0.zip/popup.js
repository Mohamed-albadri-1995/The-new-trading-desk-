'use strict';

/* ══════════════════════════════════════════════════════════════════════
   Trade Desk — clean rebuild (Market + Screener)
   Market regime dashboard + sector short-term bias + 3-screener scanner.
   Tap any index or sector for a daily candle chart (lightweight-charts).
   ══════════════════════════════════════════════════════════════════════ */

// ── tiny helpers ───────────────────────────────────────────────────────
function $(id) { return document.getElementById(id); }
function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}
function num(v) { return typeof v === 'number' && isFinite(v) ? v : null; }
function fmtVolShort(n) {
  if (n == null || !isFinite(n)) return '—';
  var a = Math.abs(n);
  if (a >= 1e9) return (n / 1e9).toFixed(2) + 'B';
  if (a >= 1e6) return (n / 1e6).toFixed(2) + 'M';
  if (a >= 1e3) return (n / 1e3).toFixed(1) + 'K';
  return String(Math.round(n));
}
function fmtETTime(ms) {
  try {
    return new Date(ms).toLocaleTimeString('en-US',
      { timeZone: 'America/New_York', hour: 'numeric', minute: '2-digit' });
  } catch (_) { return ''; }
}
// Single backend round-trip (background POSTs to TradingView).
function tvScan(body) {
  return new Promise(function (resolve, reject) {
    chrome.runtime.sendMessage({ action: 'tvScan', body: body }, function (resp) {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      if (!resp || !resp.ok) return reject(new Error(resp ? resp.error : 'no response'));
      resolve(resp.data);
    });
  });
}
// Map a TV row (item.d[]) to a named object given the column order.
function rowObj(item, cols) {
  var d = item.d || [], o = {};
  cols.forEach(function (c, i) { o[c] = d[i]; });
  return o;
}

// ── persistent settings + chrome.storage helpers ───────────────────────
var DEFAULT_SETTINGS = {
  hotImmediate: 80,     // sector score ≥ this → HOT immediately
  hotSustained: 65,     // score ≥ this → HOT only after holding hotSustainedDays sessions
  hotSustainedDays: 2,  // consecutive refresh sessions (distinct ET days) required to enter
  hotFloor: 40,         // once HOT, stays HOT while score ≥ this floor
  hotCoolDays: 2,       // drop HOT only after score is below the floor for MORE than this many sessions
  finnhubKey: '',
  finnhubNews: true     // include Finnhub news on cards (alongside TradingView); off = TradingView only
};
var settings = Object.assign({}, DEFAULT_SETTINGS);

function storageGet(keys) {
  return new Promise(function (resolve) {
    try {
      chrome.storage.local.get(keys, function (res) {
        resolve(chrome.runtime.lastError ? {} : (res || {}));
      });
    } catch (_) { resolve({}); }
  });
}
function storageSet(obj) {
  return new Promise(function (resolve) {
    try { chrome.storage.local.set(obj, function () { resolve(!chrome.runtime.lastError); }); }
    catch (_) { resolve(false); }
  });
}
function loadSettings() {
  return storageGet(['settings']).then(function (r) {
    settings = Object.assign({}, DEFAULT_SETTINGS, r.settings || {});
    return settings;
  });
}
function saveSettings() { return storageSet({ settings: settings }); }

// ET calendar date as YYYY-MM-DD (en-CA renders ISO-style); keys the hot history.
function etDateStr(ms) {
  try {
    return new Date(ms == null ? Date.now() : ms)
      .toLocaleDateString('en-CA', { timeZone: 'America/New_York' });
  } catch (_) { return new Date().toISOString().slice(0, 10); }
}

// Relative "x ago" for news timestamps (ms).
function fmtAgo(ts) {
  if (!ts) return '';
  var s = Math.max(0, (Date.now() - ts) / 1000);
  if (s < 3600) return Math.round(s / 60) + 'm ago';
  if (s < 86400) return Math.round(s / 3600) + 'h ago';
  return Math.round(s / 86400) + 'd ago';
}

// News round-trip (background fetches Finnhub + TradingView).
function fetchNews(symbol, tvSymbol) {
  var fhKey = settings.finnhubNews ? (settings.finnhubKey || '') : '';
  return new Promise(function (resolve, reject) {
    chrome.runtime.sendMessage(
      { action: 'news', symbol: symbol, tvSymbol: tvSymbol || '', finnhubKey: fhKey },
      function (resp) {
        if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
        if (!resp || !resp.ok) return reject(new Error(resp ? resp.error : 'no response'));
        resolve(resp);
      });
  });
}

// ══════════════════════════════════════════════════════════════════════
// CONSTANTS
// ══════════════════════════════════════════════════════════════════════

// Stock-type gate applied to every screener (common/preferred/DR/non-ETF fund; no pre-IPO).
var STOCK_FILTER2 = {
  operator: 'and',
  operands: [
    { operation: { operator: 'or', operands: [
      { operation: { operator: 'and', operands: [
        { expression: { left: 'type', operation: 'equal', right: 'stock' } },
        { expression: { left: 'typespecs', operation: 'has', right: ['common'] } } ] } },
      { operation: { operator: 'and', operands: [
        { expression: { left: 'type', operation: 'equal', right: 'stock' } },
        { expression: { left: 'typespecs', operation: 'has', right: ['preferred'] } } ] } },
      { operation: { operator: 'and', operands: [
        { expression: { left: 'type', operation: 'equal', right: 'dr' } } ] } },
      { operation: { operator: 'and', operands: [
        { expression: { left: 'type', operation: 'equal', right: 'fund' } },
        { expression: { left: 'typespecs', operation: 'has_none_of', right: ['etf', 'mutual', 'closedend'] } } ] } }
    ] } },
    { expression: { left: 'typespecs', operation: 'has_none_of', right: ['pre-ipo'] } }
  ]
};

// Column set requested for every screener (order = the response contract).
var TV_COLUMNS = [
  'ticker-view', 'open', 'close', 'change', 'relative_volume_10d_calc',
  'relative_volume_intraday|5', 'market_cap_basic', 'sector', 'industry',
  'change_from_open', 'VWAP',
  'High.1M', 'Low.1M', 'high', 'low', 'ATR',
  'short_percentage_of_float', 'float_shares_outstanding',
  'EMA9', 'EMA13', 'EMA20', 'EMA50', 'SMA5'
];

// The 3 screeners. Each runs its own filter set + sort against the scanner.
var SCREENERS = {
  trend: {
    name: '🍏 Trend + RVOL', short: 'Trend',
    filters: [
      { left: 'close', operation: 'egreater', right: 20 },
      { left: 'close', operation: 'egreater', right: 'SMA5' },
      { left: 'close', operation: 'egreater', right: 'VWAP' },
      { left: 'close|1W', operation: 'greater', right: 'VWAP|1W' },
      { left: 'close|1M', operation: 'greater', right: 'VWAP|1M' },
      { left: 'EMA50|1', operation: 'greater', right: 'EMA120|1' },
      { left: 'close|1', operation: 'egreater', right: 'EMA50|1' },
      { left: 'average_volume_90d_calc', operation: 'greater', right: 1000000 },
      { left: 'VWAP', operation: 'egreater', right: 'SMA75|5' },
      { left: 'relative_volume_intraday|5', operation: 'greater', right: 3 },
      { left: 'relative_volume_10d_calc', operation: 'greater', right: 1.5 },
      { left: 'close', operation: 'egreater', right: 1 }
    ],
    sort: { sortBy: 'change', sortOrder: 'desc' }
  },
  premarket: {
    name: '🔵 Pre-Market Volume', short: 'Pre-Mkt',
    filters: [
      { left: 'close', operation: 'egreater', right: 0.5 },
      { left: 'close', operation: 'egreater', right: 1 },
      { left: 'average_volume_10d_calc', operation: 'greater', right: 2000000 },
      { left: 'relative_volume_10d_calc', operation: 'greater', right: 3 },
      { left: 'premarket_volume', operation: 'greater', right: 1500000 }
    ],
    sort: { sortBy: 'premarket_volume', sortOrder: 'desc' }
  },
  bigmoves: {
    name: '❤️ Big Moves', short: 'Big Move',
    filters: [
      { left: 'relative_volume_10d_calc', operation: 'greater', right: 10 },
      { left: 'close', operation: 'egreater', right: 2 },
      { left: 'average_volume_10d_calc', operation: 'greater', right: 2000000 }
    ],
    sort: { sortBy: 'relative_volume_10d_calc', sortOrder: 'desc' }
  }
};

// Sector ETF map (15 broad sectors).
var SECTOR_ETF_MAP = {
  'Technology': 'AMEX:XLK', 'Finance': 'AMEX:XLF', 'Energy Minerals': 'AMEX:XLE',
  'Health Technology': 'AMEX:XLV', 'Producer Manufacturing': 'AMEX:XLI',
  'Communications': 'AMEX:XLC', 'Consumer Durables': 'AMEX:XLY',
  'Consumer Non-Durables': 'AMEX:XLP', 'Non-Energy Minerals': 'AMEX:XLB',
  'Finance/Real Estate': 'AMEX:XLRE', 'Utilities': 'AMEX:XLU',
  'Electronic Technology': 'AMEX:SMH', 'Health Services': 'AMEX:IBB',
  'Retail Trade': 'AMEX:XRT', 'Transportation': 'AMEX:XTN'
};
var SECTOR_ETF_REVERSE = {};
Object.keys(SECTOR_ETF_MAP).forEach(function (k) { SECTOR_ETF_REVERSE[SECTOR_ETF_MAP[k]] = k; });

// Granular sub-sector → broad key (trimmed but covers the common cases).
var SECTOR_FALLBACK_MAP = {
  'technology services': 'Technology', 'packaged software': 'Technology', 'software': 'Technology',
  'internet software/services': 'Technology', 'data processing services': 'Technology',
  'semiconductors': 'Electronic Technology', 'electronic components': 'Electronic Technology',
  'computer processing hardware': 'Electronic Technology', 'telecommunications equipment': 'Electronic Technology',
  'biotechnology': 'Health Technology', 'pharmaceuticals: major': 'Health Technology',
  'pharmaceuticals: other': 'Health Technology', 'medical specialties': 'Health Technology',
  'managed health care': 'Health Services', 'services to the health industry': 'Health Services',
  'major banks': 'Finance', 'regional banks': 'Finance', 'investment banks/brokers': 'Finance',
  'real estate investment trusts': 'Finance/Real Estate', 'oil & gas production': 'Energy Minerals',
  'integrated oil': 'Energy Minerals', 'oilfield services/equipment': 'Energy Minerals',
  'precious metals': 'Non-Energy Minerals', 'steel': 'Non-Energy Minerals', 'aluminum': 'Non-Energy Minerals',
  'aerospace & defense': 'Producer Manufacturing', 'industrial machinery': 'Producer Manufacturing',
  'motor vehicles': 'Consumer Durables', 'apparel/footwear': 'Consumer Non-Durables',
  'specialty stores': 'Retail Trade', 'internet retail': 'Retail Trade', 'discount stores': 'Retail Trade',
  'airlines': 'Transportation', 'trucking': 'Transportation', 'railroads': 'Transportation',
  'major telecommunications': 'Communications', 'electric utilities': 'Utilities',
  // ── TV top-level sectors that aren't ETF-bucket keys themselves ──
  // Without these, stocks in them resolve to nothing and the card shows a raw,
  // un-scored sector that can never reflect a hot bucket. Each is folded into
  // the closest scored proxy so the card and Market tab judge sectors the same
  // way. 'Miscellaneous' is left unmapped on purpose (no sensible ETF proxy).
  'commercial services': 'Producer Manufacturing',
  'consumer services': 'Consumer Durables',
  'distribution services': 'Producer Manufacturing',
  'industrial services': 'Producer Manufacturing',
  'process industries': 'Non-Energy Minerals'
};
function resolveBroadSector(stock) {
  if (!stock) return null;
  var sec = (stock.sector || '').toLowerCase().trim();
  var ind = (stock.industry || '').toLowerCase().trim();
  if (!sec && !ind) return null;
  if (sec) {
    var exact = Object.keys(SECTOR_ETF_MAP).find(function (k) { return k.toLowerCase() === sec; });
    if (exact) return exact;
  }
  if (sec && SECTOR_FALLBACK_MAP[sec]) return SECTOR_FALLBACK_MAP[sec];
  if (ind && SECTOR_FALLBACK_MAP[ind]) return SECTOR_FALLBACK_MAP[ind];
  // guarded substring: multi-word ETF keys only (never bare "Technology")
  var guard = Object.keys(SECTOR_ETF_MAP).filter(function (k) { return /[ /]/.test(k); });
  if (sec) { var g = guard.find(function (k) { return sec.indexOf(k.toLowerCase()) !== -1; }); if (g) return g; }
  if (ind) { var g2 = guard.find(function (k) { return ind.indexOf(k.toLowerCase()) !== -1; }); if (g2) return g2; }
  return null;
}

var MARKET_TICKERS = ['AMEX:SPY', 'NASDAQ:QQQ', 'AMEX:DIA', 'AMEX:IWM', 'TVC:VIX'];

// ══════════════════════════════════════════════════════════════════════
// THEME REGISTRY — ticker/industry → theme slug (powers the card's Themes line)
// ══════════════════════════════════════════════════════════════════════
var EE_THEMES = {
  AI_SOFTWARE: ['NVDA', 'AVGO', 'AMD', 'ARM', 'SMCI', 'PLTR', 'AI', 'BBAI', 'SOUN', 'AAPL', 'META', 'MSFT', 'GOOGL', 'AMZN', 'ORCL', 'NOW', 'CRM', 'ADBE', 'SNOW', 'MDB', 'DDOG', 'NET', 'CFLT', 'GTLB', 'S', 'PATH', 'DOCN', 'UPST', 'AFRM'],
  AI_POWER: ['CEG', 'VST', 'NRG', 'TLN', 'ETR', 'PCG', 'GEV', 'AES', 'DUK', 'SO', 'D', 'ED', 'EXC', 'XEL', 'AEP', 'WEC'],
  SEMIS_EQUIP: ['AMAT', 'LRCX', 'KLAC', 'ASML', 'TER', 'ENTG', 'ACLS', 'ONTO', 'CAMT', 'ICHR', 'COHU', 'KLIC', 'UCTT', 'NVMI'],
  SEMIS_FABS: ['TSM', 'INTC', 'GFS', 'UMC', 'STM', 'ON', 'MU', 'WDC', 'STX', 'MRVL', 'QCOM', 'TXN', 'MCHP', 'ADI', 'NXPI', 'SWKS', 'QRVO'],
  DATA_CENTER: ['EQIX', 'DLR', 'VRT', 'AAON', 'ETN', 'DELL', 'ANET', 'HPE', 'PSTG', 'NTAP', 'CIEN', 'LITE', 'COHR', 'APH', 'GLW'],
  QUANTUM: ['IONQ', 'RGTI', 'QBTS', 'QUBT', 'ARQQ', 'LAES', 'HON', 'IBM'],
  NUCLEAR: ['SMR', 'OKLO', 'LEU', 'UUUU', 'NNE', 'BWXT', 'CCJ', 'UEC', 'URG', 'DNN', 'ASPI', 'CVV', 'BW'],
  OIL_MAJORS: ['XOM', 'CVX', 'COP', 'EOG', 'OXY', 'PSX', 'MPC', 'VLO', 'MRO', 'HES', 'FANG', 'DVN', 'CTRA', 'APA', 'BP', 'SHEL'],
  NATGAS_EP: ['AR', 'RRC', 'EQT', 'CHK', 'SWN', 'CRK', 'MTDR', 'OVV', 'CIVI', 'PR'],
  OIL_SERVICES: ['SLB', 'HAL', 'BKR', 'WFRD', 'NOV', 'FTI', 'RIG', 'OII', 'NESR', 'HP', 'LBRT'],
  SOLAR: ['FSLR', 'ENPH', 'SEDG', 'RUN', 'NOVA', 'SHLS', 'ARRY', 'JKS', 'CSIQ', 'MAXN', 'SPWR'],
  OBESITY_GLP1: ['LLY', 'NVO', 'VKTX', 'ALT', 'TERN', 'ZEAL', 'SGMO', 'AMGN'],
  BIOTECH_ONC: ['MRNA', 'BNTX', 'RNA', 'CRSP', 'BEAM', 'NTLA', 'NKTR', 'RGNX', 'EDIT', 'BMRN', 'RARE', 'EXEL', 'IONS', 'SRPT'],
  BIOTECH_SMALL: ['SAVA', 'AXSM', 'CELG', 'PRTA', 'DNLI', 'KROS', 'DYN', 'INSM', 'NUVL', 'NVAX', 'OCUL', 'VERV', 'MDGL', 'MLTX', 'VRNA', 'LQDA', 'ARWR'],
  PHARMA_LARGE: ['JNJ', 'PFE', 'MRK', 'ABBV', 'BMY', 'GILD', 'REGN', 'VRTX', 'BIIB', 'ALNY'],
  MEDTECH: ['ISRG', 'MDT', 'BSX', 'SYK', 'EW', 'ABT', 'BDX', 'ZBH', 'BAX', 'HOLX', 'ALGN', 'TMO', 'DHR', 'ZTS', 'IDXX'],
  CYBERSECURITY: ['CRWD', 'PANW', 'ZS', 'FTNT', 'S', 'NET', 'OKTA', 'QLYS', 'RBRK', 'CYBR', 'TENB', 'VRNS', 'CHKP', 'OSPN', 'RPD'],
  FINTECH: ['PYPL', 'SQ', 'SOFI', 'HOOD', 'NU', 'MELI', 'TOST', 'LC', 'DAVE', 'OPFI', 'FOUR', 'PAGS', 'STNE', 'XYZ', 'GPN', 'FIS', 'FI'],
  BANKS_BIG: ['JPM', 'BAC', 'WFC', 'C', 'GS', 'MS', 'BK', 'USB', 'TFC', 'PNC', 'COF', 'AXP'],
  BANKS_REGIONAL: ['RF', 'KEY', 'CMA', 'ZION', 'MTB', 'HBAN', 'CFG', 'FITB', 'TCBI', 'WAL', 'WTFC', 'SNV', 'CUBI', 'NYCB', 'OZK'],
  INSURANCE: ['BRK.B', 'UNH', 'ELV', 'CVS', 'CI', 'HUM', 'PGR', 'TRV', 'ALL', 'MET', 'PRU', 'AIG', 'CB', 'HIG', 'LNC'],
  CRYPTO_STK: ['COIN', 'MSTR', 'RIOT', 'MARA', 'CLSK', 'BITF', 'HUT', 'CIFR', 'CORZ', 'WULF', 'IREN', 'BTBT', 'BTDR', 'CAN', 'SMLR'],
  CHINA_ADR: ['BABA', 'PDD', 'JD', 'NIO', 'LI', 'XPEV', 'BIDU', 'TME', 'TCOM', 'YMM', 'FUTU', 'TIGR', 'BZ', 'KC', 'VIPS', 'IQ', 'BILI', 'YY', 'HTHT'],
  RARE_EARTH: ['MP', 'TMC', 'USAR', 'UAMY', 'LAC', 'IE'],
  LITHIUM: ['ALB', 'LAC', 'SQM', 'LTHM', 'SGML'],
  GOLD_SILVER: ['NEM', 'GOLD', 'AEM', 'FNV', 'WPM', 'PAAS', 'CDE', 'HL', 'EXK', 'AG', 'FSM', 'SILV', 'GATO'],
  STEEL_METALS: ['NUE', 'STLD', 'CLF', 'X', 'MT', 'RS', 'CMC', 'TMST'],
  SHIPPING: ['ZIM', 'STNG', 'FRO', 'EURN', 'INSW', 'DHT', 'TRMD', 'HAFN', 'NMM', 'MATX', 'KEX', 'GOGL', 'GSL'],
  DEFENSE: ['LMT', 'RTX', 'NOC', 'GD', 'LDOS', 'KTOS', 'AVAV', 'BA', 'GE', 'HEI', 'TDG', 'HII', 'LHX', 'TXT', 'SAIC'],
  SPACE: ['RKLB', 'ASTS', 'LUNR', 'SATS', 'IRDM', 'PL', 'RDW', 'SPIR', 'VSAT', 'MAXR'],
  DRONES_ROBOT: ['KTOS', 'ONDS', 'UMAC', 'UAVS', 'RCAT', 'AIRO', 'XPON', 'MVIS', 'SYM'],
  AIRLINES: ['UAL', 'DAL', 'AAL', 'LUV', 'JBLU', 'ALK', 'SAVE', 'HA', 'ALGT', 'SNCY', 'CPA', 'VLRS', 'CEA'],
  AUTO_EV: ['TSLA', 'RIVN', 'LCID', 'NIO', 'LI', 'XPEV', 'FFIE', 'GOEV'],
  AUTO_LEGACY: ['F', 'GM', 'TM', 'HMC', 'STLA'],
  CANNABIS: ['MSOS', 'TLRY', 'CGC', 'ACB', 'CRON', 'SNDL', 'OGI', 'HITI', 'VFF', 'GRWG', 'TCNNF', 'CURLF', 'GTBIF', 'CRLBF', 'VRNOF'],
  RETAIL_MEME: ['GME', 'AMC', 'KOSS', 'NAK', 'BBIG', 'MULN', 'GNS', 'SIRI'],
  RETAIL_DISC: ['COST', 'WMT', 'TGT', 'HD', 'LOW', 'BBY', 'ROST', 'TJX', 'DLTR', 'DG', 'FIVE', 'BURL', 'OLLI', 'ULTA'],
  RESTAURANTS: ['MCD', 'SBUX', 'CMG', 'YUM', 'DRI', 'TXRH', 'CAVA', 'WING', 'SHAK', 'DPZ', 'DASH', 'PZZA'],
  HOMEBUILDERS: ['DHI', 'LEN', 'NVR', 'PHM', 'TOL', 'KBH', 'MHO', 'TMHC', 'MTH', 'CCS', 'GRBK', 'LGIH'],
  CHEMICALS: ['LIN', 'APD', 'SHW', 'ECL', 'DD', 'DOW', 'PPG', 'LYB', 'FMC', 'CE', 'EMN', 'IFF', 'RPM', 'HUN']
};
var EE_TICKER_TO_THEMES = (function () {
  var m = {};
  Object.keys(EE_THEMES).forEach(function (t) {
    EE_THEMES[t].forEach(function (s) { (m[s] = m[s] || []).push(t); });
  });
  return m;
})();
// Industry substring → theme slug. First match wins. Catches tickers not in the roster.
var EE_INDUSTRY_TO_THEME = {
  'semiconductor equipment': 'SEMIS_EQUIP', 'semiconductors': 'SEMIS_FABS',
  'utilities—regulated electric': 'AI_POWER', 'utilities—independent power': 'AI_POWER',
  'utilities - regulated electric': 'AI_POWER', 'utilities - independent power': 'AI_POWER',
  'uranium': 'NUCLEAR', 'solar': 'SOLAR',
  'oil & gas integrated': 'OIL_MAJORS', 'oil & gas e&p': 'OIL_MAJORS', 'oil & gas midstream': 'OIL_MAJORS',
  'oil & gas refining': 'OIL_MAJORS', 'oil & gas equipment': 'OIL_SERVICES', 'oil & gas drilling': 'OIL_SERVICES',
  'biotechnology': 'BIOTECH_ONC', 'drug manufacturers—general': 'PHARMA_LARGE', 'drug manufacturers—specialty': 'PHARMA_LARGE',
  'drug manufacturers - general': 'PHARMA_LARGE', 'drug manufacturers - specialty': 'PHARMA_LARGE',
  'drug manufacturers—specialty & generic': 'PHARMA_LARGE', 'pharmaceuticals: major': 'PHARMA_LARGE', 'pharmaceuticals: generic': 'PHARMA_LARGE',
  'medical devices': 'MEDTECH', 'medical instruments': 'MEDTECH', 'diagnostics & research': 'MEDTECH', 'medical specialties': 'MEDTECH',
  'banks—diversified': 'BANKS_BIG', 'banks—regional': 'BANKS_REGIONAL', 'banks - diversified': 'BANKS_BIG', 'banks - regional': 'BANKS_REGIONAL',
  'major banks': 'BANKS_BIG', 'regional banks': 'BANKS_REGIONAL',
  'insurance—life': 'INSURANCE', 'insurance—property & casualty': 'INSURANCE', 'insurance—diversified': 'INSURANCE',
  'insurance—specialty': 'INSURANCE', 'insurance - life': 'INSURANCE', 'insurance - property': 'INSURANCE', 'insurance - diversified': 'INSURANCE',
  'credit services': 'FINTECH', 'gold': 'GOLD_SILVER', 'silver': 'GOLD_SILVER', 'steel': 'STEEL_METALS',
  'lithium': 'LITHIUM', 'rare earth': 'RARE_EARTH', 'other metals/minerals': 'RARE_EARTH', 'metal fabrication': 'STEEL_METALS',
  'specialty chemicals': 'CHEMICALS', 'chemicals': 'CHEMICALS',
  'aerospace & defense': 'DEFENSE', 'airlines': 'AIRLINES', 'air freight/couriers': 'AIRLINES',
  'marine shipping': 'SHIPPING', 'shipping & ports': 'SHIPPING', 'auto manufacturers': 'AUTO_LEGACY',
  'residential construction': 'HOMEBUILDERS', 'restaurants': 'RESTAURANTS', 'food: major diversified': 'RESTAURANTS',
  'discount stores': 'RETAIL_DISC', 'home improvement retail': 'RETAIL_DISC', 'apparel/footwear retail': 'RETAIL_DISC',
  'internet retail': 'RETAIL_DISC', 'specialty stores': 'RETAIL_DISC', 'food retail': 'RETAIL_DISC',
  'computer peripherals': 'DATA_CENTER', 'computer processing hardware': 'DATA_CENTER', 'computer communications': 'DATA_CENTER',
  'packaged software': 'AI_SOFTWARE', 'application software': 'AI_SOFTWARE', 'data processing services': 'AI_SOFTWARE', 'internet software/services': 'AI_SOFTWARE',
  'electronic equipment/instruments': 'SEMIS_EQUIP', 'electronic production equipment': 'SEMIS_EQUIP',
  'oilfield services/equipment': 'OIL_SERVICES', 'integrated oil': 'OIL_MAJORS',
  'biotechnology - other': 'BIOTECH_ONC', 'miscellaneous commercial services': 'FINTECH'
};
function classifyByIndustry(industry) {
  if (!industry) return null;
  var ind = String(industry).toLowerCase();
  for (var k in EE_INDUSTRY_TO_THEME) { if (ind.indexOf(k) !== -1) return EE_INDUSTRY_TO_THEME[k]; }
  return null;
}
// Themes for a stock: hardcoded roster first, then industry classification.
function themesForTicker(ticker, industry) {
  var t = String(ticker || '').toUpperCase();
  if (EE_TICKER_TO_THEMES[t]) return EE_TICKER_TO_THEMES[t];
  var byInd = classifyByIndustry(industry);
  return byInd ? [byInd] : [];
}

// ══════════════════════════════════════════════════════════════════════
// REGIME ENGINE
// ══════════════════════════════════════════════════════════════════════
var REGIME_MATRIX = {
  'BULLISH|UPTREND': 'STRONG_UP', 'BULLISH|PULLBACK': 'PULLBACK_BULL', 'BULLISH|REBOUND': 'UP',
  'BULLISH|SIDEWAYS': 'CHOP_BULL', 'BULLISH|DOWNTREND': 'CORRECTION',
  'RECOVERING|UPTREND': 'WEAK_UP', 'RECOVERING|PULLBACK': 'RECOVERY', 'RECOVERING|REBOUND': 'RECOVERY',
  'RECOVERING|SIDEWAYS': 'BASING', 'RECOVERING|DOWNTREND': 'DOWN',
  'WEAKENING|UPTREND': 'RECOVERY', 'WEAKENING|PULLBACK': 'TOPPING', 'WEAKENING|REBOUND': 'BEAR_RALLY',
  'WEAKENING|SIDEWAYS': 'CHOP_BEAR', 'WEAKENING|DOWNTREND': 'DOWN',
  'BEARISH|UPTREND': 'BEAR_RALLY', 'BEARISH|PULLBACK': 'DOWN', 'BEARISH|REBOUND': 'BEAR_RALLY',
  'BEARISH|SIDEWAYS': 'BASING', 'BEARISH|DOWNTREND': 'STRONG_DOWN'
};
var REGIME_CATALOG = {
  EXTENDED_UP: { label: 'Extended uptrend', icon: '🟢⚠️', color: '#fbbf24', bias: 'LONG' },
  STRONG_UP: { label: 'Strong uptrend', icon: '🟢🟢', color: '#4ade80', bias: 'LONG' },
  UP: { label: 'Uptrend (resuming)', icon: '🟢', color: '#4ade80', bias: 'LONG' },
  WEAK_UP: { label: 'Early uptrend (unconfirmed)', icon: '🟡↑', color: '#a3e635', bias: 'LONG' },
  PULLBACK_BULL: { label: 'Bull-market pullback', icon: '🟡⤵', color: '#fbbf24', bias: 'LONG' },
  RECOVERY: { label: 'Recovery attempt', icon: '🟡↗', color: '#fbbf24', bias: 'NEUTRAL' },
  BASING: { label: 'Basing / bottoming', icon: '⚪▁', color: '#94a3b8', bias: 'NEUTRAL' },
  CHOP_BULL: { label: 'Choppy range (above 200DMA)', icon: '⚪〰', color: '#94a3b8', bias: 'NEUTRAL' },
  CHOP_BEAR: { label: 'Choppy range (below 200DMA)', icon: '⚪〰', color: '#94a3b8', bias: 'NEUTRAL' },
  CORRECTION: { label: 'Correction (bull intact)', icon: '🟠⤵', color: '#fb923c', bias: 'NEUTRAL' },
  TOPPING: { label: 'Topping / breaking down', icon: '🟠▼', color: '#fb923c', bias: 'SHORT' },
  BEAR_RALLY: { label: 'Bear-market rally', icon: '🟠↗', color: '#fb923c', bias: 'NEUTRAL' },
  DOWN: { label: 'Downtrend', icon: '🔴', color: '#f87171', bias: 'SHORT' },
  STRONG_DOWN: { label: 'Strong downtrend', icon: '🔴🔴', color: '#ef4444', bias: 'SHORT' },
  CAPITULATION: { label: 'Capitulation / oversold', icon: '🔴⚠️', color: '#ef4444', bias: 'SHORT' },
  UNKNOWN: { label: 'Unknown', icon: '❔', color: '#64748b', bias: 'NEUTRAL' }
};
var REGIME_GUIDANCE = {
  STRONG_UP: { BULLISH: ['AGGRESSIVE_LONG', 'Long + mid confirmed and today agrees — trade longs aggressively, full size on A-setups.'], NEUTRAL: ['LONG', 'Trend intact, today undecided — longs at normal size, demand intraday confirmation.'], BEARISH: ['CAUTIOUS_LONG', 'Red day inside a strong uptrend — buy-the-dip only, reduced size, no chasing.'] },
  EXTENDED_UP: { BULLISH: ['CAUTIOUS_LONG', 'Uptrend but stretched (upper BB) — ride existing longs, take partials; fresh entries on pullbacks only.'], NEUTRAL: ['WAIT', 'Extended and stalling — no new entries; protect open profits with tighter stops.'], BEARISH: ['WAIT', 'Extension + red day — pullback likely; no new longs, tighten stops hard.'] },
  UP: { BULLISH: ['LONG', 'Trend resuming with confirmation — longs at normal size.'], NEUTRAL: ['CAUTIOUS_LONG', 'Rebound resuming but mixed — longs reduced size, quick to cut.'], BEARISH: ['WAIT', 'Rebound stalling today — wait for the trend to reassert.'] },
  WEAK_UP: { BULLISH: ['CAUTIOUS_LONG', 'Early uptrend, long-term unconfirmed — longs in leaders only, moderate size.'], NEUTRAL: ['WAIT', 'Early trend, no confirmation — watch leaders, keep powder dry.'], BEARISH: ['WAIT', 'Early trend being tested — stand aside until it proves itself.'] },
  PULLBACK_BULL: { BULLISH: ['CAUTIOUS_LONG', 'Bull pullback likely ending — reclaim/bounce entries, tight risk.'], NEUTRAL: ['WAIT', 'Pullback still working — let it finish, build the watchlist.'], BEARISH: ['WAIT', 'Pullback accelerating — don\'t catch the knife, wait for a green day.'] },
  RECOVERY: { BULLISH: ['CAUTIOUS_LONG', 'Recovery confirming — selective longs in the strongest names, moderate size.'], NEUTRAL: ['WAIT', 'Recovery unconfirmed — wait; failed recoveries are fast losers.'], BEARISH: ['FLAT', 'Recovery failing today — stand aside.'] },
  BASING: { BULLISH: ['CAUTIOUS_LONG', 'Base building with a green day — early breakout probes, small size.'], NEUTRAL: ['WAIT', 'Base building — range tactics small, or wait for the breakout.'], BEARISH: ['FLAT', 'Base under pressure — no positions until the range resolves.'] },
  CHOP_BULL: { BULLISH: ['CAUTIOUS_LONG', 'Chop with a bull backdrop — day trades only, smaller size, take profits fast.'], NEUTRAL: ['WAIT', 'Choppy — sit out or minimal size; chop eats swings.'], BEARISH: ['WAIT', 'Chop leaning red — no swings, protect capital.'] },
  CHOP_BEAR: { BULLISH: ['WAIT', 'Bounce inside chop under the 200DMA — scalps only.'], NEUTRAL: ['FLAT', 'Directionless under the 200DMA — highest-chop, lowest-edge. Stand aside.'], BEARISH: ['CAUTIOUS_SHORT', 'Chop resolving lower — small shorts on breakdowns only.'] },
  CORRECTION: { BULLISH: ['WAIT', 'Possible end of the correction — small probes until mid-term turns up.'], NEUTRAL: ['FLAT', 'Correction in progress — defensive, cash is a position.'], BEARISH: ['CAUTIOUS_SHORT', 'Correction active — shorts for experienced only (bull can snap back).'] },
  TOPPING: { BULLISH: ['WAIT', 'Bounce inside a topping structure — don\'t trust it, no new longs.'], NEUTRAL: ['CAUTIOUS_SHORT', 'Distribution forming — reduce exposure, prepare shorts.'], BEARISH: ['SHORT', 'Breakdown confirming — short setups, no longs.'] },
  BEAR_RALLY: { BULLISH: ['CAUTIOUS_LONG', 'Tradable bounce in a bear market — quick longs only, sell into strength, no swings.'], NEUTRAL: ['WAIT', 'Bear rally losing steam — take bounce profits, don\'t add.'], BEARISH: ['CAUTIOUS_SHORT', 'Rally failing — exit bounce longs, look for short re-entries.'] },
  DOWN: { BULLISH: ['WAIT', 'Bounce inside a downtrend — scalps only, small, sell fast.'], NEUTRAL: ['CAUTIOUS_SHORT', 'Downtrend intact — short bias; longs only as quick scalps.'], BEARISH: ['SHORT', 'Downtrend confirmed today — short bias, avoid longs.'] },
  STRONG_DOWN: { BULLISH: ['WAIT', 'Green day in a strong downtrend — bear-rally risk, no fresh positions for most.'], NEUTRAL: ['SHORT', 'Strong downtrend — risk-off, shorts/cash.'], BEARISH: ['AGGRESSIVE_SHORT', 'All levels agree down — shorts/cash only.'] },
  CAPITULATION: { BULLISH: ['WAIT', 'Oversold extreme bouncing — violent both ways, experienced scalps only.'], NEUTRAL: ['CAUTIOUS_SHORT', 'Capitulation zone — do NOT add shorts into the hole, snap-back risk extreme.'], BEARISH: ['CAUTIOUS_SHORT', 'Capitulation continuing — trail existing shorts, no fresh shorts here.'] },
  UNKNOWN: { BULLISH: ['WAIT', 'Market levels unknown — refresh Market Data.'], NEUTRAL: ['WAIT', 'Market levels unknown — refresh Market Data.'], BEARISH: ['WAIT', 'Market levels unknown — refresh Market Data.'] }
};
function regimeClassify(longTerm, stage, bb, shortBias) {
  var L = String(longTerm || '').toUpperCase(), S = String(stage || '').toUpperCase();
  var B = String(bb || '').toUpperCase(), SH = String(shortBias || '').toUpperCase();
  if (SH !== 'BULLISH' && SH !== 'BEARISH') SH = 'NEUTRAL';
  var slug = REGIME_MATRIX[L + '|' + S] || 'UNKNOWN';
  if (slug === 'STRONG_UP' && B === 'UPPER') slug = 'EXTENDED_UP';
  if (slug === 'STRONG_DOWN' && B === 'LOWER') slug = 'CAPITULATION';
  var cat = REGIME_CATALOG[slug] || REGIME_CATALOG.UNKNOWN;
  var g = (REGIME_GUIDANCE[slug] || REGIME_GUIDANCE.UNKNOWN)[SH];
  var known = 0;
  if (REGIME_MATRIX[L + '|' + S] !== undefined) known += 2; else if (L && L !== 'UNKNOWN') known++;
  if (B === 'UPPER' || B === 'MID' || B === 'LOWER') known++;
  var confidence = known >= 3 ? 'HIGH' : known === 2 ? 'MEDIUM' : 'LOW';
  if (slug === 'UNKNOWN') confidence = 'LOW';
  var aligned = (cat.bias === 'LONG' && SH === 'BULLISH') || (cat.bias === 'SHORT' && SH === 'BEARISH') ? true
    : (cat.bias === 'NEUTRAL' || SH === 'NEUTRAL') ? null : false;
  return { slug: slug, label: cat.label, icon: cat.icon, color: cat.color, bias: cat.bias,
    stance: g[0], guidance: g[1], confidence: confidence, aligned: aligned,
    inputs: { longTerm: L || 'UNKNOWN', stage: S || 'UNKNOWN', bb: B || 'UNKNOWN', shortBias: SH } };
}
function regimeStanceColor(s) {
  return ({ AGGRESSIVE_LONG: '#22c55e', LONG: '#4ade80', CAUTIOUS_LONG: '#a3e635', WAIT: '#fbbf24',
    FLAT: '#94a3b8', CAUTIOUS_SHORT: '#fb923c', SHORT: '#f87171', AGGRESSIVE_SHORT: '#ef4444' })[s] || '#94a3b8';
}
function regimePlaybook(rg) {
  if (!rg || rg.slug === 'UNKNOWN') return 'Refresh Market Data to read today\u2019s regime.';
  var turning = rg.confidence === 'LOW' || rg.stance === 'WAIT' || rg.stance === 'FLAT' || rg.aligned === false;
  if (turning) return '\u26a0 Market undecided / turning — scan, but wait for it to commit, then re-scan. Don\u2019t force a side.';
  if (rg.bias === 'LONG') return 'Look for LONGS — run scanners, prioritise the strongest regime-fit names.';
  if (rg.bias === 'SHORT') return 'Look for SHORTS — breakdowns / weak names that fit the regime.';
  return 'No directional edge — trade light or stand aside.';
}

// ══════════════════════════════════════════════════════════════════════
// MARKET-LEVEL COMPUTATIONS
// ══════════════════════════════════════════════════════════════════════
function computeMarketBias(ix) {
  var s = 0;
  function add(d, up, dn) { if (!d) return; if (d.change > up) s++; if (d.change < dn) s--; }
  add(ix.SPY, 0.3, -0.3); add(ix.QQQ, 0.3, -0.3); add(ix.IWM, 0.3, -0.3);
  if (ix.VIX) { if (ix.VIX.change > 3) s -= 2; else if (ix.VIX.change > 1) s--; else if (ix.VIX.change < -2) s++; }
  if (ix.SPY) { if (ix.SPY.weekChg > 1) s++; if (ix.SPY.weekChg < -1) s--; }
  if (ix.QQQ) { if (ix.QQQ.weekChg > 1) s++; if (ix.QQQ.weekChg < -1) s--; }
  return s >= 3 ? 'BULLISH' : s <= -3 ? 'BEARISH' : 'NEUTRAL';
}
function computeMarketStage(ix) {
  var src = ix.SPY, name = 'SPY';
  function ok(d) { return d && num(d.close) != null && num(d.sma5) != null && num(d.sma20) != null; }
  if (!ok(src)) { if (ok(ix.QQQ)) { src = ix.QQQ; name = 'QQQ'; } else return { stage: 'UNKNOWN', stageLabel: 'Indicators unavailable', bb: 'UNKNOWN', bbPct: null, signals: [], bull: 0, src: '' }; }
  var sig = [];
  function add(label, lhs, rhs, tf) {
    if (num(lhs) == null || num(rhs) == null) { sig.push({ label: label, state: 'unknown', tf: tf }); return; }
    sig.push({ label: label, state: lhs > rhs ? 'bull' : 'bear', tf: tf });
  }
  add('Close > 5DMA', src.close, src.sma5, 'D');
  add('Close > 20DMA', src.close, src.sma20, 'D');
  add('5DMA > 20DMA', src.sma5, src.sma20, 'D');
  add('20DMA > 50DMA', src.sma20, src.sma50, 'D');
  add('1H Close > 20MA', src.closeH, src.sma20H, 'H');
  add('1H 5MA > 20MA', src.sma5H, src.sma20H, 'H');
  var bull = sig.filter(function (x) { return x.state === 'bull'; }).length;
  var unk = sig.filter(function (x) { return x.state === 'unknown'; }).length;
  var ca5 = num(src.close) != null && num(src.sma5) != null ? src.close > src.sma5 : null;
  var s5a20 = num(src.sma5) != null && num(src.sma20) != null ? src.sma5 > src.sma20 : null;
  var stage, label;
  if (bull >= 5) { stage = 'UPTREND'; label = 'Uptrend — buyers in control'; }
  else if (bull === 4 && ca5 === true) { stage = 'UPTREND'; label = 'Uptrend — buyers in control'; }
  else if (bull >= 3 && bull <= 4 && ca5 === false && s5a20 === true) { stage = 'PULLBACK'; label = 'Pullback — uptrend correction'; }
  else if (bull >= 2 && bull <= 3 && ca5 === true && s5a20 === false) { stage = 'REBOUND'; label = 'Rebound — counter-rally in downtrend'; }
  else if (bull >= 2 && bull <= 3) { stage = 'SIDEWAYS'; label = 'Sideways — no clear edge'; }
  else { stage = 'DOWNTREND'; label = 'Downtrend — sellers in control'; }
  // BB position (daily, hourly fallback)
  var bb = 'UNKNOWN', bbPct = null;
  var up = src.bbUpper, lo = src.bbLower, cl = src.close;
  if (num(up) == null || num(lo) == null) { up = src.bbUpperH; lo = src.bbLowerH; cl = src.closeH; }
  if (num(up) != null && num(lo) != null && num(cl) != null && up > lo) {
    var p = (cl - lo) / (up - lo); p = Math.max(0, Math.min(1, p));
    bbPct = p; bb = p >= 0.75 ? 'UPPER' : p <= 0.25 ? 'LOWER' : 'MID';
  }
  return { stage: stage, stageLabel: label, bb: bb, bbPct: bbPct, signals: sig, bull: bull, unk: unk, src: name };
}
function computeLongTermBias(ix) {
  var src = ix.SPY, name = 'SPY';
  function ok(d) { return d && num(d.close) != null && num(d.sma200) != null && num(d.sma50) != null; }
  if (!ok(src)) { if (ok(ix.QQQ)) { src = ix.QQQ; name = 'QQQ'; } else return { bias: 'UNKNOWN', label: '200DMA unavailable', dist: null }; }
  var above = src.close > src.sma200, golden = src.sma50 > src.sma200;
  var dist = src.sma200 > 0 ? (src.close - src.sma200) / src.sma200 * 100 : null;
  var bias, label;
  if (above && golden) { bias = 'BULLISH'; label = 'Long-term uptrend (above 200DMA + golden cross)'; }
  else if (above && !golden) { bias = 'RECOVERING'; label = 'Recovering — above 200DMA but 50<200 (death cross)'; }
  else if (!above && golden) { bias = 'WEAKENING'; label = 'Weakening — below 200DMA but 50>200 (golden cross intact)'; }
  else { bias = 'BEARISH'; label = 'Long-term downtrend (below 200DMA + death cross)'; }
  return { bias: bias, label: label, dist: dist, src: name };
}
// ── Direction-aware SECTOR SHORT-TERM BIAS (single source of sector truth) ─
function clampN(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v; }
function sectorShortTermBias(name, etf, spy) {
  var e = etf[name];
  if (!e) return { dir: 'NEUTRAL', score: 0, dRS: 0, wRS: 0, parts: [] };
  var spyD = num(spy && spy.change) || 0, spyW = num(spy && spy.weekChg) || 0;
  var eD = num(e.change) || 0, eW = num(e.weekChg) || 0;
  var dRS = eD - spyD;   // day relative strength vs SPY (the divergence signal)
  var wRS = eW - spyW;   // week relative strength vs SPY
  var parts = [], s = 0, c;
  function push(label, val, detail) { parts.push({ label: label, val: Math.round(val * 10) / 10, detail: detail }); }
  c = clampN(eD / 1.5, -1, 1) * 18; s += c; push('Day move', c, (eD >= 0 ? '+' : '') + eD.toFixed(2) + '%');
  c = clampN(eW / 4, -1, 1) * 14; s += c; push('Week move', c, (eW >= 0 ? '+' : '') + eW.toFixed(2) + '%');
  c = clampN(dRS / 1.2, -1, 1) * 20; s += c; push('RS vs SPY (today)', c, (dRS >= 0 ? '+' : '') + dRS.toFixed(2) + '%');
  c = clampN(wRS / 3, -1, 1) * 16; s += c; push('RS vs SPY (week)', c, (wRS >= 0 ? '+' : '') + wRS.toFixed(2) + '%');
  if (num(e.close) != null && num(e.vwap) != null && e.vwap > 0) {
    c = e.close > e.vwap ? 10 : -10; s += c; push('VWAP position', c, e.close > e.vwap ? 'above VWAP' : 'below VWAP');
  }
  if (num(e.adx) != null && e.adx > 20) {
    c = (eD >= 0 ? 1 : -1) * Math.min((e.adx - 20) / 30, 1) * 12; s += c;
    push('Trend strength (ADX ' + Math.round(e.adx) + ')', c, eD >= 0 ? 'trending up' : 'trending down');
  }
  if (num(e.rvol) != null && e.rvol >= 1.2) {
    c = (eD >= 0 ? 1 : -1) * 10; s += c;
    push('Volume (RVOL ' + e.rvol.toFixed(1) + 'x)', c, eD >= 0 ? 'confirms up' : 'confirms down');
  }
  s = clampN(s, -100, 100);
  var dir = s >= 18 ? 'BULLISH' : s <= -18 ? 'BEARISH' : 'NEUTRAL';
  return { dir: dir, score: Math.round(s), dRS: Math.round(dRS * 100) / 100, wRS: Math.round(wRS * 100) / 100, parts: parts };
}
function computeSectorBiasScores(etf, spy) {
  var out = {};
  Object.keys(etf).forEach(function (k) { out[k] = sectorShortTermBias(k, etf, spy); });
  return out;
}

// ── HOT SECTOR state machine (enter → hold → cool off) ──────────────────
// Persisted per sector so 'hot' is sticky and doesn't flip day to day:
//   ENTER hot:  score ≥ immediate (instant), OR score ≥ sustained for N sessions.
//   STAY hot:   as long as score ≥ floor (even if it falls below 'sustained').
//   COOL off:   only after score stays below the floor for MORE than C sessions.
// A "session" = one distinct ET day on which you refresh. Same-day re-refreshes
// recompute today from the previous session's state, so they don't advance it.
// Stored shape: hotState[name] = { date, score, prev:{hot,susStreak,belowStreak}, cur:{…} }
function hotThresholds() {
  return {
    imm: settings.hotImmediate, sus: settings.hotSustained, susDays: settings.hotSustainedDays,
    floor: settings.hotFloor, cool: settings.hotCoolDays
  };
}
function advanceHot(prev, score, S) {
  var hot = !!prev.hot, sus = prev.susStreak || 0, below = prev.belowStreak || 0;
  if (hot) {
    if (score >= S.floor) { below = 0; }                       // holding above the floor
    else { below += 1; if (below > S.cool) { hot = false; below = 0; } } // cooled off
    if (!hot) sus = (score >= S.sus) ? 1 : 0;                  // re-seed entry streak
  } else {
    if (score >= S.imm) { hot = true; sus = 0; below = 0; }    // instant entry
    else if (score >= S.sus) { sus += 1; if (sus >= S.susDays) { hot = true; below = 0; } }
    else { sus = 0; }
  }
  return { hot: hot, susStreak: sus, belowStreak: below };
}
function hotRenderInfo(cur, score, S) {
  if (cur.hot) {
    if (score >= S.imm) return { hot: true, state: 'immediate', score: score };
    if (cur.belowStreak > 0) return { hot: true, state: 'cooling', belowStreak: cur.belowStreak, coolMax: S.cool, score: score };
    return { hot: true, state: 'holding', score: score };
  }
  if (score >= S.sus) return { hot: false, state: 'building', susStreak: cur.susStreak, susNeed: S.susDays, score: score };
  return { hot: false, state: 'cold', score: score };
}
function priorFor(rec, today) {
  if (!rec) return { hot: false, susStreak: 0, belowStreak: 0 };
  return rec.date === today ? rec.prev : rec.cur; // same-day overwrite vs new session
}
// Advance one session and persist. Returns render-ready info per sector.
function updateHotStates(scores) {
  return storageGet(['hotState']).then(function (r) {
    var store = r.hotState || {}, today = etDateStr(), S = hotThresholds(), out = {};
    Object.keys(scores).forEach(function (name) {
      var sc = scores[name].score, prev = priorFor(store[name], today);
      var cur = advanceHot(prev, sc, S);
      store[name] = { date: today, score: sc, prev: prev, cur: cur };
      out[name] = hotRenderInfo(cur, sc, S);
    });
    return storageSet({ hotState: store }).then(function () { return out; });
  });
}
// Re-apply (possibly changed) thresholds to TODAY's classification without
// advancing a new session. Can't rewrite history, but keeps today consistent.
function reclassifyHot() {
  return storageGet(['hotState']).then(function (r) {
    var store = r.hotState || {}, S = hotThresholds(), scores = marketCtx.sectorBiasScores || {}, out = {};
    Object.keys(scores).forEach(function (name) {
      var sc = scores[name].score, rec = store[name];
      var prev = rec ? rec.prev : { hot: false, susStreak: 0, belowStreak: 0 };
      var base = rec ? rec.score : sc;
      var cur = advanceHot(prev, base, S);
      if (rec) { rec.cur = cur; }
      out[name] = hotRenderInfo(cur, base, S);
    });
    return storageSet({ hotState: store }).then(function () { return out; });
  });
}

// ══════════════════════════════════════════════════════════════════════
// FETCH HELPERS
// ══════════════════════════════════════════════════════════════════════
function fetchMarketData() {
  var cols = ['close', 'change', 'Perf.W', 'VWAP', 'ADX',
    'SMA5', 'SMA20', 'SMA50', 'SMA200', 'BB.upper', 'BB.lower',
    'close|60', 'SMA5|60', 'SMA20|60', 'BB.upper|60', 'BB.lower|60'];
  return tvScan({ symbols: { tickers: MARKET_TICKERS }, columns: cols, options: { lang: 'en' } }).then(function (data) {
    var out = {};
    (data.data || []).forEach(function (item) {
      var r = rowObj(item, cols), short = String(item.s || '').replace(/^.*:/, '');
      out[short] = {
        change: num(r['change']), weekChg: num(r['Perf.W']),
        vwap: num(r['VWAP']), adx: num(r['ADX']), close: num(r['close']),
        sma5: num(r['SMA5']), sma20: num(r['SMA20']), sma50: num(r['SMA50']), sma200: num(r['SMA200']),
        bbUpper: num(r['BB.upper']), bbLower: num(r['BB.lower']),
        closeH: num(r['close|60']), sma5H: num(r['SMA5|60']), sma20H: num(r['SMA20|60']),
        bbUpperH: num(r['BB.upper|60']), bbLowerH: num(r['BB.lower|60'])
      };
    });
    return out;
  });
}
function fetchSectorETFs() {
  var cols = ['close', 'change', 'Perf.W', 'VWAP', 'ADX', 'relative_volume_intraday|5'];
  return tvScan({ symbols: { tickers: Object.values(SECTOR_ETF_MAP) }, columns: cols, options: { lang: 'en' } }).then(function (data) {
    var out = {};
    (data.data || []).forEach(function (item) {
      var sym = String(item.s || ''), r = rowObj(item, cols);
      var name = SECTOR_ETF_REVERSE[sym] || sym.replace(/^.*:/, '');
      out[name] = { etf: sym.replace(/^.*:/, ''), close: num(r['close']), change: num(r['change']),
        weekChg: num(r['Perf.W']), vwap: num(r['VWAP']),
        adx: num(r['ADX']), rvol: num(r['relative_volume_intraday|5']) };
    });
    return out;
  });
}
function fetchBreakoutStocks() {
  var cols = ['ticker-view'];
  var body = {
    columns: cols,
    filter: [
      { left: 'close', operation: 'egreater', right: 1 },
      { left: 'relative_volume_10d_calc', operation: 'greater', right: 2 },
      { left: 'Perf.W', operation: 'egreater', right: 2 }
    ],
    filter2: STOCK_FILTER2, ignore_unknown_fields: false, markets: ['america'],
    options: { lang: 'en' }, range: [0, 100], sort: { sortBy: 'Perf.W', sortOrder: 'desc' }, symbols: {}
  };
  return tvScan(body).then(function (data) {
    return (data.data || []).map(function (item) {
      var r = rowObj(item, cols), tv = r['ticker-view'], t = '';
      if (tv && typeof tv === 'object' && tv.symbol) t = tv.symbol; else if (typeof tv === 'string') t = tv; else t = String(item.s || '');
      t = t.replace(/^.*:/, '').trim();
      return { ticker: t };
    }).filter(function (s) { return s.ticker; });
  });
}

// ══════════════════════════════════════════════════════════════════════
// STATE
// ══════════════════════════════════════════════════════════════════════
var marketCtx = {
  indices: {}, sectorETFs: {}, sectorBiasScores: {}, hotStatus: {}, breakoutStocks: [],
  marketBias: 'NEUTRAL', marketStage: 'UNKNOWN', marketBB: 'UNKNOWN', stageData: null,
  marketLongTerm: 'UNKNOWN', ltData: null, lastRefresh: 0
};

// Last-rendered screener stocks, keyed by ticker — lets the shortlist star
// button look up the full row (tvSymbol, price, etc.) by ticker alone.
var scrIndex = {};
// Full shortlists store: { 'YYYY-MM-DD': { items:[…], exports:[…] } }. Loaded once,
// kept in sync on every mutation. shortlistTodaySet caches today's tickers so
// buildCard can render the correct star state synchronously.
var shortlists = {};
var shortlistTodaySet = {};

// ══════════════════════════════════════════════════════════════════════
// MARKET TAB RENDER
// ══════════════════════════════════════════════════════════════════════
function renderIdx() {
  var order = ['SPY', 'QQQ', 'DIA', 'IWM', 'VIX'];
  $('idxRow').innerHTML = order.map(function (n) {
    var d = marketCtx.indices[n];
    if (!d) return '<div class="idx-card" data-chart="' + n + '"><div class="idx-name">' + n + '</div><div class="idx-price">—</div></div>';
    var chgCls = n === 'VIX' ? (d.change > 0 ? 'neg' : 'pos') : (d.change >= 0 ? 'pos' : 'neg');
    var px = (n === 'VIX' ? '' : '$') + (d.close || 0).toFixed(2);
    return '<div class="idx-card" data-chart="' + n + '"><div class="idx-name">' + n + '</div>' +
      '<div class="idx-price">' + px + '</div>' +
      '<div class="idx-chg ' + chgCls + '">' + (d.change >= 0 ? '+' : '') + (d.change || 0).toFixed(2) + '%</div>' +
      '<div class="idx-sub">Week: ' + (d.weekChg >= 0 ? '+' : '') + (d.weekChg || 0).toFixed(1) + '%</div></div>';
  }).join('');
}

var _expanded = {};
function rowCls(state) {
  var s = String(state || '').toUpperCase();
  if (s === 'BULLISH' || s === 'UPTREND') return 'bull';
  if (s === 'BEARISH' || s === 'DOWNTREND') return 'bear';
  if (['PULLBACK', 'REBOUND', 'WEAKENING', 'RECOVERING'].indexOf(s) !== -1) return 'warn';
  return '';
}
function renderBiasPanel() {
  var host = $('biasPanel');
  var rg = regimeClassify(marketCtx.marketLongTerm, marketCtx.marketStage, marketCtx.marketBB, marketCtx.marketBias);
  var stCol = regimeStanceColor(rg.stance);
  var confirm = rg.aligned === true ? '<span class="pos">✓ short-term confirms</span>'
    : rg.aligned === false ? '<span class="neg">✗ short-term disagrees</span>'
      : '<span style="color:var(--muted)">○ short-term neutral — wait for confirmation</span>';
  var regimeHtml = '<div class="regime-box" style="border:1px solid ' + rg.color + '44;border-left:4px solid ' + rg.color + '">' +
    '<div class="regime-top"><span class="regime-name" style="color:' + rg.color + '">' + rg.icon + ' ' + esc(rg.label.toUpperCase()) + '</span>' +
    '<span class="regime-meta">regime · confidence ' + rg.confidence + '</span></div>' +
    '<div class="regime-stance" style="color:' + stCol + '">▶ ' + esc(rg.stance.replace(/_/g, ' ')) + ' — ' + esc(rg.guidance) + '</div>' +
    '<div class="regime-play">🎯 ' + esc(regimePlaybook(rg)) + '</div>' +
    '<div class="regime-inputs">Long ' + esc(rg.inputs.longTerm) + ' + Mid ' + esc(rg.inputs.stage) +
    (rg.inputs.bb !== 'UNKNOWN' ? ' + BB ' + esc(rg.inputs.bb) : '') + ' → ' + esc(rg.label) + ' · ' + confirm + '</div></div>';

  // SHORT
  var st = marketCtx.marketBias || 'NEUTRAL';
  var stIcon = st === 'BULLISH' ? '🟢 ▲' : st === 'BEARISH' ? '🔴 ▼' : '⚪ ➡';
  // MID
  var midData = marketCtx.stageData;
  var bbChip = (function () {
    var bb = marketCtx.marketBB, pct = midData && midData.bbPct != null ? midData.bbPct : null;
    var cls = bb === 'UPPER' ? 'bull' : bb === 'LOWER' ? 'bear' : 'neu';
    var txt = bb === 'UPPER' ? 'BB upper 25%' : bb === 'LOWER' ? 'BB lower 25%' : bb === 'MID' ? 'BB mid 50%' : 'BB —';
    if (pct != null) txt += ' (' + Math.round(pct * 100) + '%)';
    return '<span class="chip ' + cls + '">' + txt + '</span>';
  })();
  // LONG
  var lt = marketCtx.marketLongTerm, ltData = marketCtx.ltData;
  var ltChip = '';
  if (ltData && num(ltData.dist) != null) {
    var dp = ltData.dist;
    ltChip = '<span class="chip ' + (dp >= 0 ? 'bull' : 'bear') + '">' + (ltData.src || 'SPY') + ' ' + (dp >= 0 ? '+' : '') + dp.toFixed(2) + '% vs 200DMA</span>';
  }

  function sigDetail() {
    var sg = midData && midData.signals || [];
    if (!sg.length) return '<div class="sig-note">Refresh market data to compute signals.</div>';
    var h = '<div class="sig-note" style="margin-bottom:6px">Source ' + esc(midData.src || 'SPY') + ' · Bull ' + midData.bull + '/6' + (midData.unk ? ' · ' + midData.unk + ' unknown' : '') + '</div>';
    h += '<div class="sig-grid"><div class="sig-hdr"><span>Signal</span><span>State</span><span>TF</span></div>';
    sg.forEach(function (s) {
      var c = s.state === 'bull' ? 'sb' : s.state === 'bear' ? 'se' : 'sn';
      h += '<div class="sig-r ' + c + '"><span>' + esc(s.label) + '</span><span>' + s.state + '</span><span>' + s.tf + '</span></div>';
    });
    return h + '</div>';
  }

  function row(tier, label, val, cls, icon, chip, sub, body, key) {
    var ex = !!_expanded[key];
    return '<div class="bias-row ' + cls + '" data-key="' + key + '">' +
      '<div class="bias-head"><span class="bias-icon">' + icon + '</span>' +
      '<span class="bias-tier">' + label + '</span>' +
      '<span class="bias-val">' + esc(val) + '</span>' + (chip || '') +
      '<span class="bias-chev">' + (ex ? '▾' : '▸') + '</span></div>' +
      (sub ? '<div class="bias-sub">' + esc(sub) + '</div>' : '') +
      (ex && body ? '<div class="bias-body">' + body + '</div>' : '') + '</div>';
  }

  var refreshStr = marketCtx.lastRefresh ? 'Refreshed ' + fmtETTime(marketCtx.lastRefresh) + ' ET' : 'Not yet loaded';
  host.className = 'bias-panel';
  host.innerHTML = regimeHtml +
    row('short', 'SHORT-TERM (Today)', st, rowCls(st), stIcon, '', '', '', 'short') +
    row('mid', 'MID-TERM (Trend)', marketCtx.marketStage, rowCls(marketCtx.marketStage), (midData && midData.stage !== 'UNKNOWN' ? '📊' : '⚪'), bbChip, (midData && midData.stageLabel) || '', sigDetail(), 'mid') +
    row('long', 'LONG-TERM (200DMA)', lt, rowCls(lt), (lt !== 'UNKNOWN' ? '📈' : '⚪'), ltChip, (ltData && ltData.label) || '', (ltData ? '<div class="sig-note">' + esc(ltData.label) + '</div>' : ''), 'long') +
    '<div class="bias-foot">' + refreshStr + '</div>';

  Array.prototype.forEach.call(host.querySelectorAll('.bias-head'), function (h) {
    h.addEventListener('click', function () {
      var k = h.parentNode.getAttribute('data-key');
      _expanded[k] = !_expanded[k]; renderBiasPanel();
    });
  });
}
var _sbExpanded = {};
function renderSectorBias() {
  var el = $('sectorBias');
  if (!el) return;
  var scores = marketCtx.sectorBiasScores || {};
  var etf = marketCtx.sectorETFs || {};
  var hot = marketCtx.hotStatus || {};
  var names = Object.keys(scores);
  var breakout = (marketCtx.breakoutStocks || []).slice(0, 8).map(function (s) { return esc(s.ticker); }).join(', ');
  var breakoutLine = breakout ? '<div class="breakout-line">RVOL breakout names: ' + breakout + '</div>' : '';
  if (!names.length) { el.innerHTML = '<span class="cold-tag">Tap Refresh Market Data</span>'; return; }
  var bull = names.filter(function (n) { return scores[n].dir === 'BULLISH'; })
    .sort(function (a, b) { return scores[b].score - scores[a].score; });
  var bear = names.filter(function (n) { return scores[n].dir === 'BEARISH'; })
    .sort(function (a, b) { return scores[a].score - scores[b].score; });

  function hotBadge(n) {
    var h = hot[n];
    if (h && h.hot) {
      var why = h.state === 'cooling' ? 'cooling — below floor ' + settings.hotFloor + ' for ' + h.belowStreak + ' session(s)'
        : h.state === 'immediate' ? 'score ≥ ' + settings.hotImmediate
          : 'holding above floor ' + settings.hotFloor;
      var ic = h.state === 'cooling' ? '🔥🧊' : '🔥';
      return '<span class="hot-badge" title="' + esc(why) + '">' + ic + ' HOT</span>';
    }
    if (h && h.state === 'building')
      return '<span class="warm-badge" title="needs ' + h.susNeed + ' sessions ≥ ' + settings.hotSustained + '">🌤 ' + h.susStreak + '/' + h.susNeed + '</span>';
    return '';
  }
  function breakdown(n) {
    var sc = scores[n], h = hot[n] || {}, sym = (etf[n] && etf[n].etf) || '';
    var rows = (sc.parts || []).map(function (p) {
      var cls = p.val > 0 ? 'pos' : p.val < 0 ? 'neg' : '';
      return '<div class="sb-part"><span>' + esc(p.label) + '</span>' +
        '<span class="sub9">' + esc(p.detail || '') + '</span>' +
        '<span class="' + cls + '">' + (p.val >= 0 ? '+' : '') + p.val + '</span></div>';
    }).join('');
    var total = '<div class="sb-part sb-total"><span>Total score</span><span></span><span>' +
      (sc.score >= 0 ? '+' : '') + sc.score + '</span></div>';
    var hotExpl;
    if (h.state === 'immediate') hotExpl = '🔥 Score ' + sc.score + ' ≥ immediate threshold ' + settings.hotImmediate + ' → HOT now.';
    else if (h.state === 'holding') hotExpl = '🔥 HOT — holding at ' + sc.score + ', above the floor (' + settings.hotFloor + '). Stays HOT until it sits below ' + settings.hotFloor + ' for more than ' + settings.hotCoolDays + ' sessions.';
    else if (h.state === 'cooling') hotExpl = '🔥🧊 HOT but cooling — below the floor (' + settings.hotFloor + ') for ' + h.belowStreak + ' session(s). Drops if it stays below for more than ' + settings.hotCoolDays + ' (i.e. on session ' + (settings.hotCoolDays + 1) + ').';
    else if (h.state === 'building') hotExpl = '🌤 At ' + sc.score + ' (≥ ' + settings.hotSustained + ') for ' + h.susStreak + '/' + h.susNeed + ' sessions — one more holding session turns it HOT.';
    else hotExpl = 'Score ' + sc.score + ' is below the sustained threshold ' + settings.hotSustained + ' — not hot.';
    return '<div class="sb-body">' +
      '<div class="sb-parts">' + rows + total + '</div>' +
      '<div class="sb-hot">' + esc(hotExpl) + '</div>' +
      (sym ? '<button class="btn-mini" data-chart="' + esc(sym) + '">📈 Chart ' + esc(sym) + '</button>' : '') +
      '</div>';
  }
  function rowFor(n, cls) {
    var sc = scores[n], sym = (etf[n] && etf[n].etf) || '', ex = !!_sbExpanded[n];
    return '<div class="sb-row ' + cls + (hot[n] && hot[n].hot ? ' is-hot' : '') + '" data-sb="' + esc(n) + '">' +
      '<div class="sb-head"><span class="sb-name">' + esc(n) + (sym ? ' <span class="sub9">' + esc(sym) + '</span>' : '') + '</span>' +
      hotBadge(n) +
      '<span class="sb-score ' + cls + '">' + (sc.score > 0 ? '+' : '') + sc.score + '</span>' +
      '<span class="sb-rs sub9">RS ' + (sc.dRS >= 0 ? '+' : '') + sc.dRS + '%</span>' +
      '<span class="sb-chev">' + (ex ? '▾' : '▸') + '</span></div>' +
      (ex ? breakdown(n) : '') + '</div>';
  }
  var html = '';
  html += '<div class="bias-grp"><div class="bias-grp-hdr" style="color:var(--green-s)">▲ Leading — buyers in control (' + bull.length + ')</div>' +
    (bull.length ? bull.map(function (n) { return rowFor(n, 'bull'); }).join('') : '<span class="cold-tag">none</span>') + '</div>';
  html += '<div class="bias-grp"><div class="bias-grp-hdr" style="color:var(--red-s)">▼ Lagging — sellers in control (' + bear.length + ')</div>' +
    (bear.length ? bear.map(function (n) { return rowFor(n, 'bear'); }).join('') : '<span class="cold-tag">none</span>') + '</div>';
  el.innerHTML = html + breakoutLine;

  Array.prototype.forEach.call(el.querySelectorAll('.sb-head'), function (head) {
    head.addEventListener('click', function () {
      var n = head.parentNode.getAttribute('data-sb');
      _sbExpanded[n] = !_sbExpanded[n];
      renderSectorBias();
    });
  });
}
function renderHeatmap() {
  var el = $('heatGrid');
  var entries = Object.keys(marketCtx.sectorETFs).map(function (k) { return [k, marketCtx.sectorETFs[k]]; });
  if (!entries.length) { el.innerHTML = '<div class="empty">No sector data</div>'; return; }
  var scores = marketCtx.sectorBiasScores || {};
  entries.sort(function (a, b) {
    var sa = scores[a[0]] ? scores[a[0]].score : 0, sb = scores[b[0]] ? scores[b[0]].score : 0;
    return sb - sa;
  });
  el.innerHTML = entries.map(function (e) {
    var name = e[0], d = e[1];
    var sb = scores[name] || { dir: 'NEUTRAL', score: 0 };
    var cls = sb.dir === 'BULLISH' ? 'up' : sb.dir === 'BEARISH' ? 'dn' : '';
    var biasCls = sb.dir === 'BULLISH' ? 'pos' : sb.dir === 'BEARISH' ? 'neg' : '';
    var isHot = marketCtx.hotStatus[name] && marketCtx.hotStatus[name].hot;
    return '<div class="heat-cell ' + cls + (isHot ? ' is-hot' : '') + '" data-chart="' + esc(d.etf) + '">' +
      (isHot ? '<div class="heat-hot" title="Hot sector">🔥</div>' : '') +
      '<div class="heat-name">' + esc(name) + '</div>' +
      '<div class="heat-etf">' + esc(d.etf) + '</div>' +
      '<div class="heat-d ' + (d.change >= 0 ? 'pos' : 'neg') + '">' + (d.change >= 0 ? '+' : '') + (d.change || 0).toFixed(2) + '%</div>' +
      '<div class="heat-w">W: ' + (d.weekChg >= 0 ? '+' : '') + (d.weekChg || 0).toFixed(1) + '%</div>' +
      '<div class="heat-bias ' + biasCls + '">' + esc(sb.dir) + ' ' + (sb.score > 0 ? '+' : '') + sb.score +
        (d.adx ? ' · ADX ' + Math.round(d.adx) : '') + '</div>' +
      '</div>';
  }).join('');
}
function renderMarket() { renderIdx(); renderBiasPanel(); renderSectorBias(); renderHeatmap(); }

// ── orchestration ──────────────────────────────────────────────────────
async function refreshMarket() {
  $('mktRefresh').disabled = true;
  $('mktStatus').textContent = 'Loading market data…';
  try {
    var [etf, ix, hot] = await Promise.all([
      fetchSectorETFs().catch(function () { return {}; }),
      fetchMarketData().catch(function () { return {}; }),
      fetchBreakoutStocks().catch(function () { return []; })
    ]);
    marketCtx.indices = ix; marketCtx.sectorETFs = etf; marketCtx.breakoutStocks = hot;
    marketCtx.marketBias = computeMarketBias(ix);
    marketCtx.sectorBiasScores = computeSectorBiasScores(etf, ix.SPY);
    marketCtx.hotStatus = await updateHotStates(marketCtx.sectorBiasScores).catch(function () { return {}; });
    var sd = computeMarketStage(ix); marketCtx.marketStage = sd.stage; marketCtx.marketBB = sd.bb; marketCtx.stageData = sd;
    var lt = computeLongTermBias(ix); marketCtx.marketLongTerm = lt.bias; marketCtx.ltData = lt;
    marketCtx.lastRefresh = Date.now();
    renderMarket();
    $('mktStatus').textContent = '';
  } catch (e) {
    $('mktStatus').textContent = 'Error: ' + e.message;
  }
  $('mktRefresh').disabled = false;
}

// ══════════════════════════════════════════════════════════════════════
// SCREENER TAB
// ══════════════════════════════════════════════════════════════════════
function runScreener(key) {
  var cfg = SCREENERS[key];
  var body = {
    columns: TV_COLUMNS, filter: cfg.filters, filter2: STOCK_FILTER2,
    ignore_unknown_fields: false, markets: ['america'], options: { lang: 'en' },
    range: [0, 50], sort: cfg.sort, symbols: {}
  };
  return tvScan(body).then(function (data) {
    return (data.data || []).map(function (item) {
      var r = rowObj(item, TV_COLUMNS);
      var tv = r['ticker-view'], t = '';
      if (tv && typeof tv === 'object' && tv.symbol) t = tv.symbol; else if (typeof tv === 'string') t = tv; else t = String(item.s || '');
      t = t.replace(/^.*:/, '').trim();
      var close = num(r['close']), change = num(r['change']);
      var cfo = num(r['change_from_open']);
      return {
        ticker: t, screenerKey: key, tvSymbol: String(item.s || ''),
        price: close, open: num(r['open']), change: change,
        prevClose: (close != null && change != null && (1 + change / 100) !== 0) ? close / (1 + change / 100) : null,
        gapPct: (change != null && cfo != null) ? (change - cfo) : null,
        vwap: num(r['VWAP']),
        ema9: num(r['EMA9']), ema13: num(r['EMA13']), ema20: num(r['EMA20']), ema50: num(r['EMA50']),
        sma5: num(r['SMA5']),
        monthHigh: num(r['High.1M']), monthLow: num(r['Low.1M']),
        dayHigh: num(r['high']), dayLow: num(r['low']), atr: num(r['ATR']),
        mcap: num(r['market_cap_basic']),
        floatShares: num(r['float_shares_outstanding']),
        shortFloat: num(r['short_percentage_of_float']),
        rvol: num(r['relative_volume_intraday|5']) || num(r['relative_volume_10d_calc']),
        sector: r['sector'] || '', industry: r['industry'] || ''
      };
    }).filter(function (s) { return s.ticker; });
  });
}

// ── per-card news (lazy-loaded to respect Finnhub's 60/min free limit) ──
function renderNewsItems(resp) {
  var fh = (resp && resp.finnhub) || [], tv = (resp && resp.tradingview) || [];
  if (!fh.length && !tv.length) {
    var hint = (settings.finnhubNews && !settings.finnhubKey) ? ' <span class="sub9">(add a Finnhub key in ⚙ Settings for summaries)</span>' : '';
    return '<span class="sub9">No recent news found.' + hint + '</span>';
  }
  var html = '';
  fh.slice(0, 2).forEach(function (n) {
    html += '<div class="news-item">' +
      '<a href="' + esc(n.url) + '" target="_blank" rel="noopener noreferrer" class="news-title">' + esc(n.headline) + '</a>' +
      '<div class="news-meta sub9">' + esc(n.source || 'Finnhub') + (n.ts ? ' · ' + esc(fmtAgo(n.ts)) : '') + '</div>' +
      (n.summary ? '<div class="news-sum">' + esc(n.summary) + '</div>' : '') +
      '</div>';
  });
  tv.slice(0, 2).forEach(function (n) {
    html += '<div class="news-item">' +
      '<a href="' + esc(n.url) + '" target="_blank" rel="noopener noreferrer" class="news-title">' + esc(n.title) + '</a>' +
      '<div class="news-meta sub9">TradingView' + (n.source ? ' · ' + esc(n.source) : '') + (n.ts ? ' · ' + esc(fmtAgo(n.ts)) : '') + '</div>' +
      (n.summary ? '<div class="news-sum">' + esc(n.summary) + '</div>' : '') +
      '</div>';
  });
  return html;
}
function loadCardNews(ticker, tvSymbol, hostId) {
  var host = document.getElementById(hostId);
  if (!host) return;
  host.innerHTML = '<span class="sub9">Loading news…</span>';
  fetchNews(ticker, tvSymbol)
    .then(function (resp) { host.innerHTML = renderNewsItems(resp); })
    .catch(function (e) { host.innerHTML = '<span class="sub9">News unavailable: ' + esc(e.message) + '</span>'; });
}

function buildCard(s, matchedKeys) {
  scrIndex[s.ticker] = s;
  var L = [];
  // Price · Open · Prev close
  var p = [];
  if (s.price != null) p.push('<b>Price:</b> $' + s.price.toFixed(2));
  if (s.open != null) p.push('<b>Open:</b> $' + s.open.toFixed(2));
  if (s.prevClose != null) p.push('<b>Prev close:</b> $' + s.prevClose.toFixed(2));
  if (p.length) L.push('<div class="line">' + p.join(' &nbsp;·&nbsp; ') + '</div>');
  // VWAP
  if (s.vwap != null && s.vwap > 0) {
    var v = '<b>VWAP:</b> $' + s.vwap.toFixed(2);
    if (s.price != null) v += s.price > s.vwap ? ' <span class="pos">▲ above</span>' : s.price < s.vwap ? ' <span class="neg">▼ below</span>' : '';
    L.push('<div class="line">' + v + '</div>');
  }
  // Daily EMAs
  if (s.ema9 != null && s.ema13 != null && s.ema20 != null && s.ema50 != null) {
    var stack, above50 = s.price != null && s.price > s.ema50;
    if (s.ema9 > s.ema13 && s.ema13 > s.ema20 && s.ema20 > s.ema50) stack = '<span class="pos">9&gt;13&gt;20&gt;50 (full bull stack)</span>';
    else if (s.ema9 < s.ema13 && s.ema13 < s.ema20 && s.ema20 < s.ema50) stack = '<span class="neg">9&lt;13&lt;20&lt;50 (full bear stack)</span>';
    else if (s.ema9 > s.ema13 && s.ema13 > s.ema20) stack = '<span class="pos">9&gt;13&gt;20</span> <span class="sub9">(above 50: ' + (above50 ? 'yes' : 'no') + ')</span>';
    else if (s.ema9 < s.ema13 && s.ema13 < s.ema20) stack = '<span class="neg">9&lt;13&lt;20</span> <span class="sub9">(above 50: ' + (above50 ? 'yes' : 'no') + ')</span>';
    else stack = '<span class="sub9">mixed / consolidating</span>';
    var prices = '<span class="sub9">9: $' + s.ema9.toFixed(2) + ' · 13: $' + s.ema13.toFixed(2) + ' · 20: $' + s.ema20.toFixed(2) + ' · 50: $' + s.ema50.toFixed(2) + '</span>';
    L.push('<div class="line"><b>Daily EMAs:</b> ' + stack + '<br>' + prices + '</div>');
  }
  // 5-day MA
  if (s.sma5 != null && s.sma5 > 0 && s.price != null) {
    var side = s.price > s.sma5 ? ' <span class="pos">▲ price above</span>' : ' <span class="neg">▼ price below</span>';
    var pct5 = Math.abs(s.price - s.sma5) / s.sma5 * 100;
    var dist = '';
    if (s.atr != null && s.atr > 0 && !(s.atr > s.price * 1.5)) {
      dist = ' <span class="sub9">(' + (Math.abs(s.price - s.sma5) / s.atr).toFixed(1) + ' ATR · ' + pct5.toFixed(1) + '% away)</span>';
    } else dist = ' <span class="sub9">(' + pct5.toFixed(1) + '% away)</span>';
    L.push('<div class="line"><b>5-day MA:</b> $' + s.sma5.toFixed(2) + side + dist + '</div>');
  }
  // 1-month range
  if (s.monthHigh != null || s.monthLow != null) {
    var m = '<b>1-month range:</b>';
    if (s.monthHigh != null) {
      m += ' H $' + s.monthHigh.toFixed(2);
      if (s.price != null) { var fh = (s.price - s.monthHigh) / s.monthHigh * 100; m += ' <span class="sub9" style="color:' + (fh >= -5 ? 'var(--amber)' : 'var(--muted2)') + '">(' + (fh >= 0 ? '+' : '') + fh.toFixed(1) + '% from H)</span>'; }
    }
    if (s.monthLow != null && s.monthLow > 0) {
      m += ' / L $' + s.monthLow.toFixed(2);
      if (s.price != null) { var fl = (s.price - s.monthLow) / s.monthLow * 100; m += ' <span class="sub9" style="color:' + (fl <= 10 ? 'var(--green-s)' : 'var(--muted2)') + '">(+' + fl.toFixed(1) + '% from L)</span>'; }
    }
    L.push('<div class="line">' + m + '</div>');
  }
  // Gap
  if (s.gapPct != null) {
    var gc = s.gapPct >= 0 ? 'pos' : 'neg', gd = s.gapPct >= 0 ? '▲ gap up' : '▼ gap down';
    L.push('<div class="line"><b>Gap:</b> <span class="' + gc + '">' + (s.gapPct >= 0 ? '+' : '') + s.gapPct.toFixed(1) + '% ' + gd + '</span></div>');
  }
  // Market cap
  if (s.mcap != null && s.mcap > 0) {
    var tier = s.mcap >= 1e10 ? 'large' : s.mcap >= 2e9 ? 'mid' : s.mcap >= 3e8 ? 'small' : 'micro';
    L.push('<div class="line"><b>Market cap:</b> $' + fmtVolShort(s.mcap) + ' <span class="sub9">(' + tier + ' cap)</span></div>');
  }
  // Float
  if (s.floatShares != null && s.floatShares > 0) {
    var ft = s.floatShares < 1e7 ? ' <span class="sub9" style="color:var(--amber)">⚠ low float</span>' : s.floatShares < 5e7 ? ' <span class="sub9" style="color:var(--amber2)">small float</span>' : '';
    L.push('<div class="line"><b>Float:</b> ' + fmtVolShort(s.floatShares) + ' sh' + ft + '</div>');
  }
  // Short float
  if (s.shortFloat != null) {
    var sc = s.shortFloat >= 20 ? 'var(--amber)' : s.shortFloat >= 10 ? 'var(--amber2)' : 'var(--txt2)';
    var sn = s.shortFloat >= 20 ? ' <span class="sub9" style="color:var(--amber)">⚠ high — squeeze risk</span>' : '';
    L.push('<div class="line"><b>Short float:</b> <span style="color:' + sc + '">' + s.shortFloat.toFixed(1) + '%</span>' + sn + '</div>');
  }
  // RVOL
  if (s.rvol != null && s.rvol > 0) {
    var rc = s.rvol >= 3 ? 'pos' : s.rvol >= 1.5 ? '' : 'neg';
    L.push('<div class="line"><b>RVOL:</b> <span class="' + rc + '">' + s.rvol.toFixed(1) + 'x</span></div>');
  }
  // Move (× ATR)
  if (s.dayHigh != null && s.dayLow != null && s.atr != null && s.atr > 0) {
    if (s.price != null && s.atr > s.price * 1.5) {
      L.push('<div class="line"><b>Move:</b> <span class="sub9">— (ATR-14 unreliable)</span></div>');
    } else {
      var ranges = [s.dayHigh - s.dayLow];
      if (s.prevClose != null) { ranges.push(Math.abs(s.dayHigh - s.prevClose)); ranges.push(Math.abs(s.dayLow - s.prevClose)); }
      var mv = Math.max.apply(null, ranges) / s.atr;
      if (isFinite(mv)) {
        var mc = mv >= 3 ? 'neg' : mv >= 1 ? 'pos' : '';
        var mn = mv >= 3 ? ' (overextended)' : mv >= 1 ? ' (above avg day)' : mv < 0.5 ? ' (quiet)' : '';
        L.push('<div class="line"><b>Move:</b> <span class="' + mc + '">' + mv.toFixed(2) + '× ATR</span><span class="sub9">' + mn + '</span></div>');
      }
    }
  }

  var badges = (matchedKeys || [s.screenerKey]).map(function (k) { return '<span class="scr-badge">' + esc(SCREENERS[k].short) + '</span>'; }).join('');
  var chgCls = s.change >= 0 ? 'pos' : 'neg';

  // ── THEMES, SECTOR & MARKET — connects this card to the Market tab ──
  function biasSpan(b) {
    var cls = b === 'BULLISH' ? 'pos' : b === 'BEARISH' ? 'neg' : '';
    return '<span class="' + cls + '"' + (cls ? '' : ' style="color:var(--muted)"') + '>' + esc(b || 'NEUTRAL') + '</span>';
  }
  var themes = themesForTicker(s.ticker, s.industry);
  var themePills = themes.length
    ? themes.slice(0, 4).map(function (t) {
        return '<span class="theme-pill">· ' + esc(t) + '</span>';
      }).join(' ')
    : '<span style="color:var(--muted2)">—</span>';
  // Resolve to the SAME 15 scored buckets the Market tab uses. Only a resolved
  // bucket gets a bias/hot read; an unmapped raw sector (e.g. "Miscellaneous")
  // is shown but labelled as having no ETF proxy, instead of a misleading NEUTRAL.
  var broadResolved = resolveBroadSector(s);
  var broad = broadResolved || s.sector || '';
  var sbScore = broadResolved && marketCtx.sectorBiasScores[broadResolved];
  var hotInfo = broadResolved && marketCtx.hotStatus && marketCtx.hotStatus[broadResolved];
  var secBias = (sbScore && sbScore.dir) || 'NEUTRAL';
  var secHot = '';
  if (hotInfo && hotInfo.hot) {
    secHot = ' <span class="pos" style="font-size:10px">🔥 hot' + (sbScore ? ' +' + sbScore.score : '') + '</span>';
  } else if (sbScore && sbScore.dir === 'BULLISH') {
    secHot = ' <span class="pos" style="font-size:10px">▲ leading +' + sbScore.score + '</span>';
  } else if (sbScore && sbScore.dir === 'BEARISH') {
    secHot = ' <span class="neg" style="font-size:10px">▼ lagging ' + sbScore.score + '</span>';
  }
  var sectorLine = !broad
    ? '<span style="color:var(--muted2)">—</span>'
    : broadResolved
      ? esc(broad) + ' — ' + biasSpan(secBias) + secHot
      : esc(broad) + ' <span class="sub9">(no ETF proxy — not scored)</span>';
  var ctxHtml = '<div class="ctx-block">' +
    '<div class="ctx-hdr">🌊 THEMES, SECTOR &amp; MARKET</div>' +
    '<div class="line"><b>Themes:</b> ' + themePills + '</div>' +
    '<div class="line"><b>Sector:</b> ' + sectorLine + '</div>' +
    '<div class="line"><b>Market:</b> ' + biasSpan(marketCtx.marketBias) + '</div>' +
    '</div>';

  var newsId = 'news-' + String(s.ticker).replace(/[^A-Za-z0-9]/g, '');
  var newsBlock = '<div class="ctx-block">' +
    '<div class="ctx-hdr">📰 NEWS</div>' +
    '<div id="' + newsId + '" class="news-host">' +
      '<button class="btn-mini" data-news="' + esc(s.ticker) + '" data-tvsym="' + esc(s.tvSymbol || '') + '" data-newsid="' + newsId + '">📰 Load recent news</button>' +
    '</div></div>';

  var inList = shortlistHas(s.ticker);
  var starBtn = '<button class="sl-star' + (inList ? ' on' : '') + '" data-sl-add="' + esc(s.ticker) + '">' +
    (inList ? '★ In list' : '☆ Shortlist') + '</button>';

  return '<div class="scr-card">' +
    '<div class="scr-hdr"><span class="scr-ticker tap" data-chart="' + esc(s.ticker) + '">' + esc(s.ticker) + '</span>' +
    (s.change != null ? '<span class="scr-chg ' + chgCls + '">' + (s.change >= 0 ? '+' : '') + s.change.toFixed(2) + '%</span>' : '') +
    '<span class="scr-badges">' + badges + '</span>' + starBtn +
    (s.sector ? '<span class="scr-sector">' + esc(s.sector) + (s.industry ? ' · ' + esc(s.industry) : '') + '</span>' : '') +
    '</div>' +
    ctxHtml +
    '<div class="tech-hdr">📈 TECHNICALS</div>' +
    (L.length ? L.join('') : '<div class="empty">— no technical data —</div>') +
    newsBlock +
    '</div>';
}

async function runAllScreeners() {
  var scrBtns = $('scrButtons').querySelectorAll('[data-scr]');
  $('scrRunAll').disabled = true;
  Array.prototype.forEach.call(scrBtns, function (b) { b.disabled = true; });
  $('scrStatus').textContent = 'Running 3 screeners…';
  $('scrResults').innerHTML = '';
  try {
    if (!marketCtx.lastRefresh) await refreshMarket();
    var keys = ['trend', 'premarket', 'bigmoves'];
    var lists = await Promise.all(keys.map(function (k) { return runScreener(k).catch(function () { return []; }); }));
    // merge by ticker, collect matched screeners
    var byTicker = {};
    keys.forEach(function (k, i) {
      lists[i].forEach(function (s) {
        if (!byTicker[s.ticker]) byTicker[s.ticker] = { stock: s, keys: [] };
        if (byTicker[s.ticker].keys.indexOf(k) === -1) byTicker[s.ticker].keys.push(k);
      });
    });
    var merged = Object.keys(byTicker).map(function (t) { return byTicker[t]; });
    // sort: most screeners matched first, then by RVOL
    merged.sort(function (a, b) {
      if (b.keys.length !== a.keys.length) return b.keys.length - a.keys.length;
      return (b.stock.rvol || 0) - (a.stock.rvol || 0);
    });
    if (!merged.length) { $('scrResults').innerHTML = '<div class="empty">No matches right now. Markets may be closed or filters too tight.</div>'; }
    else { $('scrResults').innerHTML = merged.map(function (m) { return buildCard(m.stock, m.keys); }).join(''); }
    $('scrStatus').textContent = merged.length + ' unique tickers across ' + keys.length + ' screeners.';
  } catch (e) {
    $('scrStatus').textContent = 'Error: ' + e.message;
  }
  $('scrRunAll').disabled = false;
  Array.prototype.forEach.call(scrBtns, function (b) { b.disabled = false; });
}

async function runSingle(key) {
  var scrBtns = $('scrButtons').querySelectorAll('[data-scr]');
  $('scrRunAll').disabled = true;
  Array.prototype.forEach.call(scrBtns, function (b) { b.disabled = true; });
  $('scrStatus').textContent = 'Running ' + SCREENERS[key].name + '…';
  $('scrResults').innerHTML = '';
  try {
    if (!marketCtx.lastRefresh) await refreshMarket();
    var list = await runScreener(key);
    if (!list.length) $('scrResults').innerHTML = '<div class="empty">No matches right now.</div>';
    else $('scrResults').innerHTML = list.map(function (s) { return buildCard(s, [key]); }).join('');
    $('scrStatus').textContent = list.length + ' results · ' + SCREENERS[key].name;
  } catch (e) { $('scrStatus').textContent = 'Error: ' + e.message; }
  $('scrRunAll').disabled = false;
  Array.prototype.forEach.call(scrBtns, function (b) { b.disabled = false; });
}

// ══════════════════════════════════════════════════════════════════════
// SHORTLIST TAB — per-day saved picks, exportable to a TradingView watchlist
// Adds come from the Screener cards (☆ Shortlist). Lists are keyed by ET day,
// so when the date rolls over a fresh empty list starts and past days persist.
// Each export (clipboard or .txt) is logged under its day with the exact time.
// ══════════════════════════════════════════════════════════════════════
var _slExpanded = {}; // date → bool (default: today open, past days collapsed)

function todayKey() { return etDateStr(); }
function loadShortlists() {
  return storageGet(['shortlists']).then(function (r) {
    shortlists = r.shortlists || {};
    refreshShortlistCache();
    return shortlists;
  });
}
function saveShortlists() { return storageSet({ shortlists: shortlists }); }
function refreshShortlistCache() {
  shortlistTodaySet = {};
  var day = shortlists[todayKey()];
  if (day && day.items) day.items.forEach(function (it) { shortlistTodaySet[it.ticker] = true; });
}
function shortlistHas(ticker) { return !!shortlistTodaySet[ticker]; }
function toggleShortlist(ticker) {
  var key = todayKey(), day = shortlists[key];
  if (!day) { day = { items: [], exports: [] }; shortlists[key] = day; }
  var idx = day.items.findIndex(function (it) { return it.ticker === ticker; });
  if (idx >= 0) {
    day.items.splice(idx, 1);
  } else {
    var s = scrIndex[ticker] || {};
    day.items.push({
      ticker: ticker, tvSymbol: s.tvSymbol || '', price: s.price != null ? s.price : null,
      change: s.change != null ? s.change : null, sector: s.sector || '', addedAt: Date.now()
    });
  }
  refreshShortlistCache();
  return saveShortlists();
}

// DD/Mon/YYYY from a YYYY-MM-DD key.
function fmtDayLabel(key) {
  var p = String(key || '').split('-');
  if (p.length !== 3) return key;
  var mon = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][parseInt(p[1], 10) - 1] || p[1];
  return p[2] + '/' + mon + '/' + p[0];
}

// Clipboard with a textarea + execCommand fallback (Kiwi/Android friendly).
function copyText(text) {
  return new Promise(function (resolve) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () { resolve(true); }, function () { resolve(fallbackCopy(text)); });
    } else { resolve(fallbackCopy(text)); }
  });
}
function fallbackCopy(text) {
  try {
    var ta = document.createElement('textarea');
    ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.focus(); ta.select();
    var ok = document.execCommand('copy');
    document.body.removeChild(ta);
    return ok;
  } catch (_) { return false; }
}
function downloadText(filename, text) {
  try {
    var blob = new Blob([text], { type: 'text/plain' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = filename; document.body.appendChild(a); a.click();
    setTimeout(function () { try { document.body.removeChild(a); } catch (_) {} URL.revokeObjectURL(url); }, 1000);
    return true;
  } catch (_) { return false; }
}

function setShortlistStatus(msg) {
  var el = $('slStatus'); if (!el) return;
  el.textContent = msg || '';
  if (msg) setTimeout(function () { if (el.textContent === msg) el.textContent = ''; }, 4000);
}

// Build the comma-joined TradingView import string for one day.
function dayExportSymbols(day) {
  return (day.items || []).map(function (it) { return it.tvSymbol || it.ticker; });
}
function exportDay(dateKey, mode) {
  var day = shortlists[dateKey];
  if (!day || !day.items.length) { setShortlistStatus('Nothing to export for ' + fmtDayLabel(dateKey) + '.'); return; }
  var syms = dayExportSymbols(day), text = syms.join(',');
  if (!day.exports) day.exports = [];
  if (mode === 'file') {
    var fname = 'shortlist-' + dateKey + '.txt';
    var ok = downloadText(fname, text);
    day.exports.push({ at: Date.now(), count: syms.length, mode: 'file' });
    saveShortlists().then(function () {
      renderShortlist();
      setShortlistStatus(ok ? ('Saved ' + fname + ' (' + syms.length + ' symbols).') : 'Download failed — use copy instead.');
    });
  } else {
    copyText(text).then(function (ok) {
      day.exports.push({ at: Date.now(), count: syms.length, mode: 'clipboard' });
      saveShortlists().then(function () {
        renderShortlist();
        setShortlistStatus(ok ? ('Copied ' + syms.length + ' symbols — paste into TradingView › Watchlist › Import.') : 'Copy blocked — long-press the list to copy manually.');
      });
    });
  }
}

function renderShortlist() {
  var host = $('slList'); if (!host) return;
  var today = todayKey();
  var keys = Object.keys(shortlists);
  if (keys.indexOf(today) === -1) keys.push(today);   // always surface today, even if empty
  keys.sort(function (a, b) { return a < b ? 1 : a > b ? -1 : 0; }); // newest day first

  host.innerHTML = keys.map(function (key) {
    var day = shortlists[key] || { items: [], exports: [] };
    var isToday = key === today;
    var open = _slExpanded.hasOwnProperty(key) ? _slExpanded[key] : isToday;
    var count = (day.items || []).length;

    var itemsHtml = count ? day.items.slice().sort(function (a, b) { return (b.addedAt || 0) - (a.addedAt || 0); })
      .map(function (it) {
        var chg = it.change != null
          ? '<span class="sl-chg ' + (it.change >= 0 ? 'pos' : 'neg') + '">' + (it.change >= 0 ? '+' : '') + it.change.toFixed(2) + '%</span>'
          : '';
        var meta = '<span class="sl-meta">' + (it.tvSymbol ? esc(it.tvSymbol) : esc(it.ticker)) + (it.sector ? ' · ' + esc(it.sector) : '') + '</span>';
        return '<div class="sl-item">' +
          '<span class="sl-tkr" data-chart="' + esc(it.ticker) + '">' + esc(it.ticker) + '</span>' +
          chg + meta +
          '<button class="sl-del" data-sl-del="' + esc(it.ticker) + '" data-sl-date="' + esc(key) + '">✕ remove</button>' +
          '</div>';
      }).join('')
      : '<div class="sl-empty">No stocks yet. Add from the 🔎 Screener tab.</div>';

    var actions = count
      ? '<div class="sl-actions">' +
        '<button class="btn-mini" data-sl-export="' + esc(key) + '" data-sl-mode="clipboard">📋 Export → copy symbols</button>' +
        '<button class="btn-mini" data-sl-export="' + esc(key) + '" data-sl-mode="file">⬇ Save .txt</button>' +
        '</div>'
      : '';

    var exportsHtml = (day.exports && day.exports.length)
      ? '<div class="sl-exports"><b>Export history:</b>' +
        day.exports.slice().sort(function (a, b) { return (b.at || 0) - (a.at || 0); }).map(function (e) {
          return '<span class="x">✓ ' + esc(fmtETTime(e.at)) + ' ET · ' + e.count + ' symbols · ' + (e.mode === 'file' ? 'saved .txt' : 'copied') + '</span>';
        }).join('') + '</div>'
      : '';

    return '<div class="sl-day' + (isToday ? ' today' : '') + '" data-sl-day="' + esc(key) + '">' +
      '<div class="sl-head"><span class="sl-date">' + esc(fmtDayLabel(key)) + '</span>' +
      (isToday ? '<span class="sl-today-badge">TODAY</span>' : '') +
      '<span class="sl-count">' + count + ' stock' + (count === 1 ? '' : 's') + '</span>' +
      '<span class="sl-chev">' + (open ? '▾' : '▸') + '</span></div>' +
      (open ? '<div class="sl-body">' + itemsHtml + actions + exportsHtml + '</div>' : '') +
      '</div>';
  }).join('');
}

// One delegated listener for the whole shortlist pane (survives re-renders).
function initShortlist() {
  $('slList').addEventListener('click', function (ev) {
    var t = ev.target;
    // remove
    var del = t.closest && t.closest('[data-sl-del]');
    if (del) {
      var dk = del.getAttribute('data-sl-date'), tk = del.getAttribute('data-sl-del');
      var day = shortlists[dk];
      if (day && day.items) {
        var i = day.items.findIndex(function (it) { return it.ticker === tk; });
        if (i >= 0) day.items.splice(i, 1);
        refreshShortlistCache();
        saveShortlists().then(function () { renderShortlist(); });
      }
      return;
    }
    // export
    var ex = t.closest && t.closest('[data-sl-export]');
    if (ex) { exportDay(ex.getAttribute('data-sl-export'), ex.getAttribute('data-sl-mode')); return; }
    // collapse toggle (ignore taps on the ticker, which charts instead)
    var head = t.closest && t.closest('.sl-head');
    if (head) {
      var key = head.parentNode.getAttribute('data-sl-day');
      var cur = _slExpanded.hasOwnProperty(key) ? _slExpanded[key] : (key === todayKey());
      _slExpanded[key] = !cur;
      renderShortlist();
    }
  });
}

// Delegated handler for the ☆/★ star buttons on screener cards.
function initShortlistStars() {
  document.body.addEventListener('click', function (ev) {
    var btn = ev.target.closest && ev.target.closest('[data-sl-add]');
    if (!btn) return;
    var ticker = btn.getAttribute('data-sl-add');
    toggleShortlist(ticker).then(function () {
      var on = shortlistHas(ticker);
      btn.classList.toggle('on', on);
      btn.innerHTML = on ? '★ In list' : '☆ Shortlist';
      renderShortlist();
    });
  });
}


// Rendering: TradingView lightweight-charts (bundled locally).
// Data: daily OHLC via background.js (Yahoo primary, Stooq fallback).
// ══════════════════════════════════════════════════════════════════════
var chartState = { symbol: null, label: null, range: '6mo', chart: null, series: null, ro: null, reqId: 0 };

function fetchChartHistory(symbol, range) {
  return new Promise(function (resolve, reject) {
    chrome.runtime.sendMessage({ action: 'chartHistory', symbol: symbol, range: range }, function (resp) {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      if (!resp || !resp.ok) return reject(new Error(resp ? resp.error : 'no response'));
      resolve(resp);
    });
  });
}

function destroyChart() {
  if (chartState.ro) { try { chartState.ro.disconnect(); } catch (_) {} chartState.ro = null; }
  if (chartState.chart) { try { chartState.chart.remove(); } catch (_) {} }
  chartState.chart = null; chartState.series = null;
}

function buildChartInstance() {
  var host = $('chartHost');
  if (!host || typeof LightweightCharts === 'undefined') return null;
  var w = host.clientWidth || 720, h = host.clientHeight || 360;
  var chart = LightweightCharts.createChart(host, {
    width: w, height: h,
    layout: { background: { color: 'transparent' }, textColor: '#cbd5e1', fontSize: 11 },
    grid: { vertLines: { color: 'rgba(148,163,184,0.07)' }, horzLines: { color: 'rgba(148,163,184,0.07)' } },
    rightPriceScale: { borderColor: '#1e293b' },
    timeScale: { borderColor: '#1e293b', timeVisible: false, secondsVisible: false },
    crosshair: { mode: 1 },
    handleScale: true, handleScroll: true
  });
  var series = chart.addCandlestickSeries({
    upColor: '#22c55e', downColor: '#ef4444',
    borderUpColor: '#22c55e', borderDownColor: '#ef4444',
    wickUpColor: '#4ade80', wickDownColor: '#f87171',
    priceLineVisible: true, lastValueVisible: true
  });
  chartState.chart = chart; chartState.series = series;
  if (typeof ResizeObserver !== 'undefined') {
    chartState.ro = new ResizeObserver(function () {
      if (chartState.chart && host.clientWidth) chartState.chart.applyOptions({ width: host.clientWidth });
    });
    chartState.ro.observe(host);
  }
  return series;
}

function setChartNote(txt) {
  var n = $('chartNote');
  if (!n) return;
  if (txt) { n.textContent = txt; n.style.display = 'flex'; }
  else n.style.display = 'none';
}

function loadChart(range) {
  chartState.range = range;
  $('chartRange3M').classList.toggle('on', range === '3mo');
  $('chartRange6M').classList.toggle('on', range === '6mo');
  if (typeof LightweightCharts === 'undefined') { setChartNote('Chart library not loaded.'); return; }
  var myReq = ++chartState.reqId;
  setChartNote('Loading…');
  $('chartSub').textContent = '';
  fetchChartHistory(chartState.symbol, range).then(function (resp) {
    if (myReq !== chartState.reqId) return; // a newer request superseded this one
    var bars = (resp.bars || []).slice().sort(function (a, b) { return a.time < b.time ? -1 : a.time > b.time ? 1 : 0; });
    bars = bars.filter(function (b, i) { return i === 0 || b.time !== bars[i - 1].time; }); // strictly increasing time
    if (!bars.length) { setChartNote('No data for ' + esc(chartState.symbol) + '.'); return; }
    if (!chartState.series) { if (!buildChartInstance()) { setChartNote('Chart unavailable.'); return; } }
    chartState.series.setData(bars);
    chartState.chart.timeScale().fitContent();
    setChartNote('');
    var first = bars[0], last = bars[bars.length - 1];
    var pct = first.open ? (last.close - first.open) / first.open * 100 : null;
    var lbl = range === '3mo' ? '3M' : '6M';
    var pctStr = pct == null ? '' : ' · ' + (pct >= 0 ? '+' : '') + pct.toFixed(1) + '% over period';
    var src = resp.source ? ' · ' + resp.source : '';
    $('chartSub').textContent = bars.length + ' daily bars · ' + lbl + pctStr + src;
  }).catch(function (e) {
    if (myReq !== chartState.reqId) return;
    setChartNote('Couldn\u2019t load chart: ' + e.message);
  });
}

function openChart(symbol, label) {
  chartState.symbol = symbol; chartState.label = label || symbol;
  $('chartTitle').textContent = '📈 ' + chartState.label + ' — daily';
  destroyChart();
  $('chartOverlay').classList.add('open');
  // The chart instance is built inside loadChart() after the fetch resolves,
  // by which point the overlay is painted and chartHost has a real width.
  loadChart(chartState.range || '6mo');
}

function closeChart() {
  chartState.reqId++; // invalidate any in-flight load
  $('chartOverlay').classList.remove('open');
  destroyChart();
}

function initChart() {
  // Open on tap of anything carrying data-chart (index cards, heat cells, bias tags).
  document.body.addEventListener('click', function (ev) {
    var t = ev.target;
    while (t && t !== document.body && !(t.getAttribute && t.getAttribute('data-chart'))) t = t.parentNode;
    if (!t || t === document.body) return;
    var sym = t.getAttribute('data-chart');
    if (sym) { ev.preventDefault(); openChart(sym, sym); }
  });
  $('chartClose').addEventListener('click', closeChart);
  $('chartOverlay').addEventListener('click', function (ev) { if (ev.target === $('chartOverlay')) closeChart(); });
  $('chartRange3M').addEventListener('click', function () { loadChart('3mo'); });
  $('chartRange6M').addEventListener('click', function () { loadChart('6mo'); });
  document.addEventListener('keydown', function (ev) {
    if (ev.key === 'Escape' && $('chartOverlay').classList.contains('open')) closeChart();
  });
}


// ══════════════════════════════════════════════════════════════════════
// BOOT
// ══════════════════════════════════════════════════════════════════════
function initScreenerButtons() {
  $('scrButtons').innerHTML = Object.keys(SCREENERS).map(function (k) {
    return '<button class="btn btn-ghost" data-scr="' + k + '" style="flex:1">' + esc(SCREENERS[k].name) + '</button>';
  }).join('');
  Array.prototype.forEach.call($('scrButtons').querySelectorAll('[data-scr]'), function (b) {
    b.addEventListener('click', function () { runSingle(b.getAttribute('data-scr')); });
  });
}
function initTabs() {
  Array.prototype.forEach.call(document.querySelectorAll('.tab'), function (t) {
    t.addEventListener('click', function () {
      document.querySelectorAll('.tab').forEach(function (x) { x.classList.remove('active'); });
      document.querySelectorAll('.pane').forEach(function (x) { x.classList.remove('active'); });
      t.classList.add('active');
      $(t.getAttribute('data-pane')).classList.add('active');
    });
  });
}

// Delegated handler for the per-card "Load news" buttons (cards are re-rendered).
function initNews() {
  document.body.addEventListener('click', function (ev) {
    var t = ev.target;
    while (t && t !== document.body && !(t.getAttribute && t.getAttribute('data-news'))) t = t.parentNode;
    if (!t || t === document.body) return;
    loadCardNews(t.getAttribute('data-news'), t.getAttribute('data-tvsym'), t.getAttribute('data-newsid'));
  });
}

function clampInt(v, lo, hi, dflt) {
  var n = parseInt(v, 10);
  if (!isFinite(n)) n = dflt;
  return Math.max(lo, Math.min(hi, n));
}
function fillSettingsForm() {
  $('setHotImm').value = settings.hotImmediate;
  $('setHotSus').value = settings.hotSustained;
  $('setHotDays').value = settings.hotSustainedDays;
  $('setHotFloor').value = settings.hotFloor;
  $('setHotCool').value = settings.hotCoolDays;
  $('setFinnhub').value = settings.finnhubKey || '';
  $('setFinnhubNews').checked = settings.finnhubNews !== false;
}
function setSettingsStatus(msg) {
  $('setStatus').textContent = msg;
  if (msg) setTimeout(function () { $('setStatus').textContent = ''; }, 2200);
}
function recomputeHotFromStore() {
  if (!marketCtx.lastRefresh) return Promise.resolve();
  return reclassifyHot().then(function (out) {
    marketCtx.hotStatus = out;
    renderSectorBias(); renderHeatmap();
  });
}
function initSettings() {
  fillSettingsForm();
  $('setSave').addEventListener('click', function () {
    settings.hotImmediate = clampInt($('setHotImm').value, 0, 100, DEFAULT_SETTINGS.hotImmediate);
    settings.hotSustained = clampInt($('setHotSus').value, 0, 100, DEFAULT_SETTINGS.hotSustained);
    settings.hotSustainedDays = clampInt($('setHotDays').value, 1, 14, DEFAULT_SETTINGS.hotSustainedDays);
    settings.hotFloor = clampInt($('setHotFloor').value, 0, 100, DEFAULT_SETTINGS.hotFloor);
    settings.hotCoolDays = clampInt($('setHotCool').value, 1, 14, DEFAULT_SETTINGS.hotCoolDays);
    settings.finnhubKey = ($('setFinnhub').value || '').trim();
    settings.finnhubNews = !!$('setFinnhubNews').checked;
    // keep thresholds ordered: floor ≤ sustained ≤ immediate
    if (settings.hotSustained > settings.hotImmediate) settings.hotSustained = settings.hotImmediate;
    if (settings.hotFloor > settings.hotSustained) settings.hotFloor = settings.hotSustained;
    fillSettingsForm();
    saveSettings().then(function () { setSettingsStatus('Saved ✓'); return recomputeHotFromStore(); });
  });
  $('setReset').addEventListener('click', function () {
    settings = Object.assign({}, DEFAULT_SETTINGS, { finnhubKey: settings.finnhubKey, finnhubNews: settings.finnhubNews });
    fillSettingsForm();
    saveSettings().then(function () { setSettingsStatus('Thresholds reset to defaults ✓'); return recomputeHotFromStore(); });
  });
  $('setClearHist').addEventListener('click', function () {
    storageSet({ hotState: {}, sectorHistory: {} }).then(function () {
      setSettingsStatus('Hot-sector history cleared ✓');
      if (marketCtx.lastRefresh) {
        return updateHotStates(marketCtx.sectorBiasScores).then(function (out) {
          marketCtx.hotStatus = out; renderSectorBias(); renderHeatmap();
        });
      }
      marketCtx.hotStatus = {};
    });
  });
}

document.addEventListener('DOMContentLoaded', function () {
  initTabs();
  initScreenerButtons();
  initChart();
  initNews();
  initShortlist();
  initShortlistStars();
  $('mktRefresh').addEventListener('click', refreshMarket);
  $('scrRunAll').addEventListener('click', runAllScreeners);
  // load settings first (thresholds + key), then auto-load market
  loadSettings().then(function () {
    initSettings();
    refreshMarket();
  });
  loadShortlists().then(renderShortlist);
});
